import AlertToast from './AlertToast';
import EmailSettingsDialog from './EmailSettingsDialog';
import type { ArgentineKind, LocalSelection } from './ArgentineMarket';
import { localQuotes, isLocal } from './local-market';
import { fixedTermValue } from './fixed-term';
import RefreshButton from './RefreshButton';
import { isAiProvider, type AiProvider } from './ai-provider';
import ImportDocuments from './ImportDocuments';
import { createPasskey, passkeyStatus, preparePasskey, removePasskey, supportsPasskeys, type RegistrationOptions, type SavedPasskey } from './passkeys';
import { useCallback, useEffect, useMemo, useRef, useState, type ChangeEvent, type FormEvent } from 'react';
import { coinPriceOn, coinPricesNow, usdcArsNow } from './coingecko';
import { cedearPriceOn, cedearPricesNow, stockPrice, stockPricesNow } from './cedears';
import AssetSearchDialog, { type AssetKind, type PickedAsset } from './AssetSearchDialog';
import ContextMenu, { type MenuItem } from './ContextMenu';
import { INDEXES, cedearName, indexName, isIndexTicker } from './assets';
import Distribution from './Distribution';
import { lazy, Suspense } from 'react';
const PortfolioMap = lazy(() => import('./PortfolioMap'));
import MacroDashboard from './MacroDashboard';
import ContributionStreak from './ContributionStreak';
import Benchmarks from './Benchmarks';
import Dividends from './Dividends';
import MarketCalendar from './MarketCalendar';
import Inflation from './Inflation';
import AssetPerformance, { history, adjustPossibleRatios, type HistoryPoint } from './AssetPerformance';
import MarketChat from './MarketChat';
import PanelEditor from './PanelEditor';
import TopBar from './TopBar';
import Select from './Select';
import QuoteSource from './QuoteSource';
import MarketHours from './MarketHours';
import { pages, usePage } from './navigation';
import { cleanInvestment, cleanSale, readLegacyPortfolio, type Currency, type Investment, type Kind, type Period, type Sale } from './portfolio';
import { request, type Account, type Snapshot } from './account';
import { usePortfolio } from './usePortfolio';
import { usePriceAlerts } from './usePriceAlerts';
import PageLink from './PageLink';
const PricesPage = lazy(() => import('./PricesPage'));
const Goals = lazy(() => import('./Goals'));

import { HugeiconsIcon } from '@hugeicons/react';
import { ArrowReloadHorizontalIcon, Bitcoin, ChartDecreaseIcon, ChartIncreaseIcon, ChartLineIcon, CoinsBitcoinIcon, Copy01Icon, Copy02Icon, CopyPlusIcon, Delete02Icon, Edit01Icon, Edit02Icon, Estimate01Icon, LandmarkFreeIcons, LinkSquare02Icon, LoaderIcon, MoreHorizontalIcon, PlusIcon, Refresh04Icon, Search01Icon, Cancel01Icon, Upload06Icon, Upload01Icon, ChevronLeft } from '@hugeicons/core-free-icons';
type Filter = 'all' | Kind | 'index';
type AssetQuote = { id: string; date: string; kind: Exclude<Kind, 'rate'> } & ({ status: 'loading' } | { status: 'ready'; price: number; sourceDate?: string } | { status: 'error'; message: string });
type DollarRate = { nombre: string; compra: number | null; venta: number };
type Rates = Record<string, DollarRate>;
const MASK = '****';
const MONTH_MS = 1000 * 60 * 60 * 24 * 30.4375;
const kinds: { id: Filter; label: string; color: string }[] = [
    { id: 'all', label: 'Todas las inversiones', color: 'var(--muted)' },
    { id: 'rate', label: 'Con tasa', color: 'var(--c-rate)' },
    { id: 'cedear', label: 'CEDEARs', color: 'var(--c-cedear)' },
    { id: 'index', label: 'Índices', color: 'var(--c-index)' },
    { id: 'stock', label: 'Acciones', color: '#9b8cff' },
    { id: 'crypto', label: 'Criptomonedas', color: 'var(--c-crypto)' },
    { id: 'arg-stock', label: 'Acciones argentinas', color: '#7bb5d5' },
    { id: 'bond', label: 'Bonos', color: '#e1b77b' },
    { id: 'fund', label: 'Fondos comunes', color: '#b8d8a3' },
];
// Nombres de los tipos de dólar que devuelve dolarapi.com (campo "casa")
const dollarLabels: Record<string, string> = { bolsa: 'MEP', contadoconliqui: 'CCL', blue: 'Blue', oficial: 'Oficial', mayorista: 'Mayorista', cripto: 'Cripto', tarjeta: 'Tarjeta' };
// Dólares que se comparan contra USDC (la referencia de conversión de la app)
const compareOrder = ['oficial', 'bolsa', 'contadoconliqui', 'blue'];
type Usdc = { price: number; source: 'coingecko' | 'mep' };
const titleFor = (kind: Kind) => kind === 'arg-stock' ? 'Acción argentina' : kind === 'bond' ? 'Bono' : kind === 'fund' ? 'Fondo común' : kind === 'rate' ? 'Con tasa' : kind === 'cedear' ? 'CEDEAR' : kind === 'stock' ? 'Acción' : 'Cripto';
const categoryOf = (investment: Investment): Exclude<Filter, 'all'> => (investment.kind === 'cedear' || investment.kind === 'stock') && isIndexTicker(investment.coin) ? 'index' : investment.kind;
const localISO = () => { const d = new Date(); return `${d.getFullYear()}-${String(d.getMonth() + 1).padStart(2, '0')}-${String(d.getDate()).padStart(2, '0')}`; };
const dateMillis = (iso: string) => new Date(`${iso}T00:00:00`).getTime();
const money = (n: number, c: Currency) => new Intl.NumberFormat('es-AR', { style: 'currency', currency: c, maximumFractionDigits: 2 }).format(Number.isFinite(n) ? n : 0);

function AnimatedAmount({ value, currency, hidden, large = false }: { value: number; currency: Currency; hidden: boolean; large?: boolean }) {
    const [shown, setShown] = useState(0);
    const current = useRef(0);
    useEffect(() => {
        if (hidden || !Number.isFinite(value)) { current.current = 0; return; }
        if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) {
            current.current = value;
            setShown(value);
            return;
        }
        const start = current.current;
        let frame = 0;
        let started: number | undefined;
        const tick = (time: number) => {
            started ??= time;
            const progress = Math.min((time - started) / 650, 1);
            const eased = 1 - Math.pow(1 - progress, 3);
            current.current = start + (value - start) * eased;
            setShown(current.current);
            if (progress < 1) frame = requestAnimationFrame(tick);
        };
        frame = requestAnimationFrame(tick);
        return () => cancelAnimationFrame(frame);
    }, [value, hidden]);
    if (hidden) return <span className="amount-transition">{MASK}</span>;
    if (!Number.isFinite(value)) return <>—</>;
    if (!large) return <>{money(shown, currency)}</>;
    const [integer, decimals] = new Intl.NumberFormat('es-AR', { minimumFractionDigits: 2, maximumFractionDigits: 2 }).format(shown).split(',');
    return <><span className="cur">{currency === 'USD' ? 'US$' : '$'}</span>{integer}<span className="dec">,{decimals}</span></>;
}
const percent = (n: number) => `${n >= 0 ? '+' : ''}${n.toFixed(2)}%`;
const formatDate = (iso: string) => new Date(`${iso}T12:00:00`).toLocaleDateString('es-AR', { day: '2-digit', month: 'short', year: 'numeric' });
const chartDate = (time: number) => new Date(time).toLocaleDateString('es-AR', { day: 'numeric', month: 'short', year: '2-digit' });
const monthlyRate = (i: Investment) => { const r = (i.rate ?? 0) / 100; return i.period === 'month' ? r : r > -1 ? Math.pow(1 + r, 1 / 12) - 1 : -1; };
function valueAt(i: Investment, t: number, prices: Record<string, number>, now: number, officialRate?: number) {
    const start = dateMillis(i.date);
    if (t < start) return 0;
    if (i.kind === 'rate') {
        if (i.maturityDate) return fixedTermValue(i.amount, i.rate ?? 0, i.date, i.maturityDate, t);
        return i.amount * Math.pow(1 + monthlyRate(i), (t - start) / MONTH_MS);
    }
    const price = i.coin ? prices[`${i.kind}:${i.coin}`] : undefined;
    const quoteCurrency = i.kind === 'cedear' || isLocal(i) ? 'ARS' : 'USD';
    const quotedValue = i.units != null && price != null ? i.units * price : null;
    const current = quotedValue == null ? (i.costUnknown ? NaN : i.amount) : quoteCurrency === i.currency ? quotedValue : !officialRate ? NaN : i.currency === 'ARS' ? quotedValue * officialRate : quotedValue / officialRate;
    if (t >= now) return current; // Sin inventar un pronóstico de mercado.
    if (i.costUnknown) return current;
    if (now <= start) return current;
    const k = Math.max(0, Math.min(1, (t - start) / (now - start)));
    return i.amount + (current - i.amount) * k; // Aproximación visual, no historial real.
}
// Todas las cotizaciones del dólar en una sola consulta (dolarapi.com)
async function dollarsNow(): Promise<Rates> {
    const res = await fetch('https://dolarapi.com/v1/dolares');
    if (!res.ok) throw new Error('No se pudieron consultar las cotizaciones del dólar.');
    const data = await res.json();
    if (!Array.isArray(data)) throw new Error('Respuesta inesperada de dolarapi.com.');
    const out: Rates = {};
    for (const d of data) {
        if (d && typeof d.casa === 'string' && typeof d.venta === 'number' && d.venta > 0) {
            out[d.casa] = { nombre: dollarLabels[d.casa] ?? String(d.nombre ?? d.casa), compra: typeof d.compra === 'number' && d.compra > 0 ? d.compra : null, venta: d.venta };
        }
    }
    return out;
}
const field = 'w-full min-w-0 rounded-[10px] border border-[var(--line)] bg-[var(--raised)] px-3 py-2.5 text-[14px] text-[var(--ink)] placeholder:text-[var(--faint)] outline-none transition-colors focus:border-[var(--muted)]';
const label = 'mb-1.5 block text-[12px] text-[var(--muted)]';
const panel = 'rounded-[20px] border border-[var(--line)] bg-[var(--surface)]';

export default function Page({ account, onLogout }: { account: Account; onLogout: () => void }) {
    const [aiSettingsRequest, setAiSettingsRequest] = useState(0);
    const [spaceSubscreen, setSpaceSubscreen] = useState<'passkey' | 'mail' | 'ai' | null>(null);
    const [aiProvider, setAiProviderState] = useState<AiProvider>(() => { try { const saved = localStorage.getItem(`activos:ai-provider:${account.user.id}`); return isAiProvider(saved) ? saved : 'openai'; } catch { return 'openai'; } });
    const setAiProvider = useCallback((provider: AiProvider) => { setAiProviderState(provider); try { localStorage.setItem(`activos:ai-provider:${account.user.id}`, provider); } catch { /* La selección sigue disponible durante esta sesión. */ } }, [account.user.id]);
    useEffect(() => { let active = true; void request<{ providers: AiProvider[] }>('ai/keys').then(result => { if (active && result.providers.length && !result.providers.includes(aiProvider)) setAiProvider(result.providers[0]); }).catch(() => { }); return () => { active = false; }; }, [account.user.id, aiProvider, setAiProvider]);
    const { sync, view, preference, items, setItems } = usePortfolio(account);
    const savedDividendPositions = useRef(account.portfolio.investments);
    if (!view.dirty) savedDividendPositions.current = view.portfolio.investments;
    const dividendFingerprint = JSON.stringify(savedDividendPositions.current.filter(item => item.kind === 'cedear' || item.kind === 'stock').map(item => [item.id, item.name, item.kind, item.coin, item.units, item.date]));
    const [leaving, setLeaving] = useState(false);
    const [legacy, setLegacy] = useState(() => {
        try {
            if (localStorage.getItem('inversiones:migrated-to')) return null;
            const data = readLegacyPortfolio(localStorage);
            return data.investments.length ? data : null;
        } catch { return null; }
    });
    const [passkeyCount, setPasskeyCount] = useState<number | null>(null);
    const [savedPasskeys, setSavedPasskeys] = useState<SavedPasskey[]>([]);
    const [passkeyDialog, setPasskeyDialog] = useState(false);
    const [passkeyOptions, setPasskeyOptions] = useState<RegistrationOptions | null>(null);
    const [passkeyMessage, setPasskeyMessage] = useState('');
    const [passkeyBusy, setPasskeyBusy] = useState(false);
    useEffect(() => { void passkeyStatus().then(result => { setPasskeyCount(result.count); setSavedPasskeys(result.keys); }).catch(() => setPasskeyCount(null)); }, []);
    async function preparePasskeyDialog() {
        setPasskeyDialog(true); setPasskeyOptions(null); setPasskeyMessage('');
        void passkeyStatus().then(result => { setPasskeyCount(result.count); setSavedPasskeys(result.keys); }).catch(() => {});
        if (!supportsPasskeys()) { setPasskeyMessage('Este dispositivo o navegador no admite passkeys. Abrí la app en Safari con HTTPS.'); return; }
        setPasskeyBusy(true);
        try { setPasskeyOptions(await preparePasskey()); }
        catch (error) { setPasskeyMessage(error instanceof Error ? error.message : 'No se pudo preparar la passkey.'); }
        finally { setPasskeyBusy(false); }
    }
    async function enablePasskey() {
        if (!passkeyOptions || passkeyBusy) return;
        setPasskeyBusy(true); setPasskeyMessage('');
        try {
            await createPasskey(passkeyOptions);
            setPasskeyOptions(null);
            setPasskeyCount(count => count === null ? 1 : count + 1);
            void passkeyStatus().then(result => { setPasskeyCount(result.count); setSavedPasskeys(result.keys); }).catch(() => { });
            setPasskeyMessage('Passkey activada. Ya podés usarla para ingresar.');
        } catch (error) {
            setPasskeyOptions(null);
            const name = error instanceof Error ? error.name : '';
            setPasskeyMessage(name === 'NotAllowedError' ? 'La operación se canceló o venció. Volvé a intentar.' : name === 'InvalidStateError' ? 'Esta passkey ya está registrada en este dispositivo.' : error instanceof Error && error.message ? error.message : 'No se pudo activar la passkey. Volvé a intentar.');
        } finally { setPasskeyBusy(false); }
    }
    const page = usePage();
    const pageInfo = pages[page];
    const titleRef = useRef<HTMLHeadingElement>(null);
    const previousPage = useRef(page);
    const [filter, setFilter] = useState<Filter>('all');
    const [investmentView, setInvestmentView] = useState<'list' | 'map'>('list');
    const [hiddenSummaryKinds, setHiddenSummaryKinds] = useState<Exclude<Filter, 'all'>[]>([]);
    const [search, setSearch] = useState('');
    const [display, setDisplay] = preference('display');
    const [range, setRange] = useState<'7d' | '1m' | '6m' | '1a' | 'todo'>('1a');
    const [chartIndex, setChartIndex] = useState<number | null>(null);
    const [prices, setPrices] = useState<Record<string, number>>({});
    const [rates, setRates] = useState<Rates>({});
    const [usdc, setUsdc] = useState<Usdc | null>(null);
    const [hidden, setHidden] = preference('hidden');
    const [updated, setUpdated] = useState<string>('');
    const [priceError, setPriceError] = useState(false);
    const [refreshing, setRefreshing] = useState(false);
    const [theme, setTheme] = preference('theme');
    const [systemDark, setSystemDark] = useState(() => window.matchMedia('(prefers-color-scheme: dark)').matches);
    useEffect(() => {
        const media = window.matchMedia('(prefers-color-scheme: dark)');
        const update = (event: MediaQueryListEvent) => setSystemDark(event.matches);
        media.addEventListener('change', update);
        return () => media.removeEventListener('change', update);
    }, []);
    const resolvedTheme = theme === 'system' ? (systemDark ? 'dark' : 'light') : theme;
    const [modal, setModal] = useState(false);
    const [detailId, setDetailId] = useState<string | null>(null);
    const detailCloseRef = useRef<HTMLButtonElement>(null);
    const detailOpenerRef = useRef<HTMLElement | null>(null);
    useEffect(() => {
        if (!detailId) return;
        detailCloseRef.current?.focus();
        const onKey = (event: KeyboardEvent) => { if (event.key === 'Escape') setDetailId(null); };
        window.addEventListener('keydown', onKey);
        return () => { window.removeEventListener('keydown', onKey); detailOpenerRef.current?.focus(); };
    }, [detailId]);
    const [editingId, setEditingId] = useState<string | null>(null);
    const [emailSettings, setEmailSettings] = useState(false);
    const [emailSettingsRevision, setEmailSettingsRevision] = useState(0);
    useEffect(() => {
        if (!spaceSubscreen) return;
        const onNavigate = () => {
            if (window.location.pathname.replace(/\/+$/, '') === '/espacio') return;
            setPasskeyDialog(false); setEmailSettings(false); setSpaceSubscreen(null);
        };
        window.addEventListener('popstate', onNavigate);
        return () => window.removeEventListener('popstate', onNavigate);
    }, [spaceSubscreen]);
    const [assetSearch, setAssetSearch] = useState<AssetKind | null>(null);
    const [initialLocalSearch, setInitialLocalSearch] = useState<ArgentineKind | undefined>();
    const openLocalSearch = (kind: ArgentineKind) => { setInitialLocalSearch(kind); setAssetSearch('crypto'); };
    const [ctx, setCtx] = useState<{ x: number; y: number; id: string } | null>(null);
    const closeCtx = useCallback(() => setCtx(null), []);
    const [error, setError] = useState('');
    const [notice, setNotice] = useState('');
    const [importPreview, setImportPreview] = useState<{ items: Investment[]; sales: Sale[]; skipped: number } | null>(null);
    const fileRef = useRef<HTMLInputElement>(null);
    const [name, setName] = useState('');
    const [localConfirmed, setLocalConfirmed] = useState(false);
    const [selectedAsset, setSelectedAsset] = useState<PickedAsset | null>(null);
    const [amount, setAmount] = useState('');
    const [priceMode, setPriceMode] = useState<'current' | 'purchase'>('current');
    const [purchasePrice, setPurchasePrice] = useState('');
    const [date, setDate] = useState(localISO());
    const [kind, setKind] = useState<Kind>('rate');
    const [indexMode, setIndexMode] = useState(false);
    const [rate, setRate] = useState('');
    const [depositMaturity, setDepositMaturity] = useState('');
    const [period, setPeriod] = useState<Period>('year');
    const [coin, setCoin] = useState('bitcoin');
    const [assetQuote, setAssetQuote] = useState<AssetQuote | null>(null);
    const [quoteRequest, setQuoteRequest] = useState(0);
    const [currency, setCurrency] = useState<Currency>('USD');
    const [confirmDelete, setConfirmDelete] = useState<string | null>(null);
    const [sellId, setSellId] = useState<string | null>(null);
    const [sellPercent, setSellPercent] = useState('100');
    const [sellInputMode, setSellInputMode] = useState<'percent' | 'amount'>('percent');
    const [sellInputAmount, setSellInputAmount] = useState('');
    const [sellCurrency, setSellCurrency] = useState<Currency>('ARS');
    const [sellError, setSellError] = useState('');
    const [sellExecutionPrice, setSellExecutionPrice] = useState('');
    const [sellFee, setSellFee] = useState('0');
    const [panelEditor, setPanelEditor] = useState(false);
    const closePanelEditor = useCallback(() => setPanelEditor(false), []);
    useEffect(() => {
        if (!panelEditor) return;
        const onNavigate = () => { if (window.location.pathname.replace(/\/+$/, '') !== '/espacio') setPanelEditor(false); };
        window.addEventListener('popstate', onNavigate);
        return () => window.removeEventListener('popstate', onNavigate);
    }, [panelEditor]);
    const [panels] = preference('panels');
    const visiblePanels = panels ? (panels.includes('panel-v2') ? panels.filter(id => id !== 'panel-v2') : [...panels.filter(id => id !== 'inflation'), ...(panels.includes('value') ? ['macro', 'streak'] : [])]) : ['value', 'macro', 'streak', 'evolution', 'distribution', 'investments'];
    const today = Date.now();
    const fxRate = usdc?.price; // 1 USDC en pesos: referencia única de conversión
    const fxSource = usdc?.source === 'mep' ? 'DolarAPI · MEP (CoinGecko no respondió)' : 'CoinGecko · USDC/ARS';
    const cryptos = useMemo(() => [...new Set(items.filter(i => i.kind === 'crypto' && i.coin).map(i => i.coin!))], [items]);
    const cedears = useMemo(() => [...new Set(items.filter(i => i.kind === 'cedear' && i.coin).map(i => i.coin!))], [items]);
    const localItems = useMemo(() => items.filter(isLocal), [items]);
    const stocks = useMemo(() => [...new Set(items.filter(i => i.kind === 'stock' && i.coin).map(i => i.coin!))], [items]);
    const assetId = kind === 'crypto' || kind === 'fund' ? coin.trim().toLowerCase() : coin.trim().toUpperCase();
    const quoteSource = kind === 'crypto' ? 'CoinGecko' : kind === 'stock' ? 'Data912 o Yahoo Finance' : 'Data912';
    const todayDate = localISO();
    const activeQuote = modal && kind !== 'rate' && assetQuote?.id === assetId && assetQuote.date === todayDate && assetQuote.kind === kind ? assetQuote : null;
    const quotePrice = activeQuote?.status === 'ready' ? activeQuote.price : undefined;
    const officialRate = fxRate;
    const quoteCurrency: Currency = ['cedear', 'arg-stock', 'bond', 'fund'].includes(kind) ? 'ARS' : 'USD';
    const convertedAmount = currency === quoteCurrency ? Number(amount) : !fxRate ? NaN : currency === 'USD' ? Number(amount) * fxRate : Number(amount) / fxRate;
    const selectedPrice = priceMode === 'purchase' ? Number(purchasePrice) : quotePrice;
    const previewUnits = selectedPrice && Number.isFinite(selectedPrice) && selectedPrice > 0 && Number.isFinite(convertedAmount) && convertedAmount > 0 ? convertedAmount / selectedPrice : undefined;
    useEffect(() => {
        if (!modal || kind === 'rate' || kind === 'arg-stock' || kind === 'bond' || kind === 'fund' || !assetId) {
            return;
        }
        const controller = new AbortController();
        const timer = window.setTimeout(async () => {
            setAssetQuote({ id: assetId, date: todayDate, kind, status: 'loading' });
            try {
                const quote = kind === 'crypto' ? { price: await coinPriceOn(assetId, todayDate, todayDate, controller.signal) } : kind === 'stock' ? await stockPrice(assetId, controller.signal) : await cedearPriceOn(assetId, todayDate, todayDate, controller.signal);
                if (!controller.signal.aborted) setAssetQuote({ id: assetId, date: todayDate, kind, status: 'ready', ...quote });
            } catch (error) {
                if (!controller.signal.aborted) setAssetQuote({ id: assetId, date: todayDate, kind, status: 'error', message: error instanceof Error ? error.message : 'No se pudo consultar el precio. Volvé a intentar.' });
            }
        }, 600);
        return () => { window.clearTimeout(timer); controller.abort(); };
    }, [modal, kind, assetId, todayDate, quoteRequest]);
    useEffect(() => {
        document.title = `${pageInfo.label} · Inversiones`;
        if (previousPage.current !== page) {
            window.scrollTo({ top: 0, behavior: 'instant' });
            titleRef.current?.focus({ preventScroll: true });
            previousPage.current = page;
        }
    }, [page, pageInfo.label]);
    const refresh = useCallback(async () => {
        setRefreshing(true); setPriceError(false);
        const results = await Promise.allSettled([coinPricesNow(cryptos), cedearPricesNow(cedears), dollarsNow(), usdcArsNow(), stockPricesNow(stocks), localQuotes(localItems)]);
        const [cryptoResult, cedearResult, dollarResult, usdcResult, stockResult, localResult] = results;
        setPrices(prev => ({ ...prev, ...(cryptoResult.status === 'fulfilled' ? cryptoResult.value : {}), ...(cedearResult.status === 'fulfilled' ? cedearResult.value : {}), ...(stockResult.status === 'fulfilled' ? stockResult.value : {}), ...(localResult.status === 'fulfilled' ? localResult.value : {}) }));
        const gotDollars = dollarResult.status === 'fulfilled' && Object.keys(dollarResult.value).length > 0;
        if (dollarResult.status === 'fulfilled' && gotDollars) setRates(prev => ({ ...prev, ...dollarResult.value }));
        if (usdcResult.status === 'fulfilled') setUsdc({ price: usdcResult.value, source: 'coingecko' });
        else if (dollarResult.status === 'fulfilled' && dollarResult.value.bolsa) setUsdc({ price: dollarResult.value.bolsa.venta, source: 'mep' });
        setPriceError(results.some(r => r.status === 'rejected') || (dollarResult.status === 'fulfilled' && !gotDollars) || (localResult.status === 'fulfilled' && localItems.some(item => !localResult.value[`${item.kind}:${item.coin}`])));
        setUpdated(new Date().toLocaleTimeString('es-AR', { hour: '2-digit', minute: '2-digit' }));
        setRefreshing(false);
    }, [cryptos, cedears, stocks, localItems]);
    useEffect(() => { void refresh(); }, [refresh]);
    const fx = (v: number, from: Currency) => from === display ? v : !fxRate ? NaN : display === 'USD' ? v / fxRate : v * fxRate;
    // Con "ocultar montos" activo, todo importe se muestra como ****
    const fmt = (v: number) => hidden ? MASK : Number.isFinite(v) ? money(v, display) : '—';
    const mny = (n: number, c: Currency) => hidden ? MASK : Number.isFinite(n) ? money(n, c) : '—';
    const current = items.reduce((s, i) => s + fx(valueAt(i, today, prices, today, officialRate), i.currency), 0);
    const summaryItems = items.filter(i => !hiddenSummaryKinds.includes(categoryOf(i)));
    const summaryInvested = summaryItems.some(i => i.costUnknown) ? NaN : summaryItems.reduce((s, i) => s + (dateMillis(i.date) <= today ? fx(i.amount, i.currency) : 0), 0);
    const summaryCurrent = summaryItems.reduce((s, i) => s + fx(valueAt(i, today, prices, today, officialRate), i.currency), 0);
    const summaryGain = summaryCurrent - summaryInvested;
    const summaryGainPct = Number.isFinite(summaryInvested) ? summaryInvested > 0 ? summaryGain / summaryInvested * 100 : 0 : NaN;
    const filtered = items.filter(i => (filter === 'all' || categoryOf(i) === filter) && `${i.name} ${i.coin ?? ''}`.toLowerCase().includes(search.toLowerCase())).sort((a, b) => b.date.localeCompare(a.date));
    const allCount = (kind: Filter) => kind === 'all' ? items.length : items.filter(i => categoryOf(i) === kind).length;
    const colorOf = (k: Filter) => kinds.find(v => v.id === k)!.color;
    const valueOf = (list: Investment[]) => list.reduce((s, i) => s + fx(valueAt(i, today, prices, today, officialRate), i.currency), 0);
    const alerts = view.portfolio.alerts ?? [];
    const alertStatuses = usePriceAlerts(alerts, items.map(item => ({ kind: item.kind, id: item.coin ?? '', value: fx(valueAt(item, today, prices, today, officialRate), item.currency) })));
    const triggeredAlerts = alerts.filter(alert => alertStatuses[alert.id]?.state === 'triggered');
    const shownAlertKey = `alza-shown-alerts:${account.user.id}`;
    const [shownAlerts, setShownAlerts] = useState<string[]>(() => { try { const value = JSON.parse(localStorage.getItem(`alza-shown-alerts:${account.user.id}`) || '[]'); return Array.isArray(value) ? value.filter(id => typeof id === 'string') : []; } catch { return []; } });
    const unseenAlerts = triggeredAlerts.filter(alert => !shownAlerts.includes(alert.id));
    const alertSignature = unseenAlerts.map(alert => alert.id).sort().join('|');
    useEffect(() => {
        if (!alertSignature || page === 'prices') return;
        try { const saved = JSON.parse(localStorage.getItem(shownAlertKey) || '[]'); const prior = Array.isArray(saved) ? saved.filter(id => typeof id === 'string') : []; localStorage.setItem(shownAlertKey, JSON.stringify([...new Set([...prior, ...unseenAlerts.map(alert => alert.id)])])); } catch { /* almacenamiento no disponible */ }
    }, [alertSignature, page, shownAlertKey]);
    const dismissAlerts = () => setShownAlerts(current => [...new Set([...current, ...unseenAlerts.map(alert => alert.id)])]);
    const notificationKey = `alza-alert-history:${account.user.id}`;
    const [alertHistory, setAlertHistory] = useState<{ id: string; alertId: string; title: string; message: string; time: number }[]>(() => { try { const value = JSON.parse(localStorage.getItem(`alza-alert-history:${account.user.id}`) || '[]'); return Array.isArray(value) ? value : []; } catch { return []; } });
    const previousAlertStates = useRef<Record<string, string>>((() => { try { return JSON.parse(localStorage.getItem(`${notificationKey}:states`) || '{}'); } catch { return {}; } })());
    useEffect(() => {
        const previous = previousAlertStates.current;
        const additions = alerts.flatMap(alert => {
            const status = alertStatuses[alert.id];
            if (!status || status.state === 'unavailable') return [];
            const was = previous[alert.id];
            previous[alert.id] = status.state;
            return status.state === 'triggered' && was !== 'triggered' ? [{ id: crypto.randomUUID(), alertId: alert.id, title: alert.assetName, message: status.message, time: Date.now() }] : [];
        });
        try { localStorage.setItem(`${notificationKey}:states`, JSON.stringify(previous)); } catch { /* almacenamiento no disponible */ }
        if (additions.length) setAlertHistory(current => [...additions, ...current].slice(0, 100));
    }, [JSON.stringify(alertStatuses), JSON.stringify(alerts)]);
    useEffect(() => { try { localStorage.setItem(notificationKey, JSON.stringify(alertHistory)); } catch { /* almacenamiento no disponible */ } }, [notificationKey, alertHistory]);

    const byKind = (['rate', 'cedear', 'index', 'stock', 'crypto', 'arg-stock', 'bond', 'fund'] as const).map(k => { const list = items.filter(i => categoryOf(i) === k); return { id: k, label: kinds.find(v => v.id === k)!.label, color: colorOf(k), value: valueOf(list), count: list.length }; });
    const byCurrency = [
        { label: 'Dólares (USD)', color: 'var(--sig)', value: valueOf(items.filter(i => i.currency === 'USD')), count: items.filter(i => i.currency === 'USD').length },
        { label: 'Pesos (ARS)', color: 'var(--c-rate)', value: valueOf(items.filter(i => i.currency === 'ARS')), count: items.filter(i => i.currency === 'ARS').length },
    ];
    const palette = ['#a8d5ba', '#e7b77d', '#91b5e8', '#d49cba', '#c6b5e4', '#e1d38d', '#80c7c1', '#e49e8c'];
    // Datos del emisor del CEDEAR; los ETF no se atribuyen a un solo sector o país.
    const classifications: Record<string, [string, string]> = {
        AAPL: ['Tecnología', 'Estados Unidos'], MSFT: ['Tecnología', 'Estados Unidos'], NVDA: ['Tecnología', 'Estados Unidos'], AMD: ['Tecnología', 'Estados Unidos'], INTC: ['Tecnología', 'Estados Unidos'], ORCL: ['Tecnología', 'Estados Unidos'], AVGO: ['Tecnología', 'Estados Unidos'], CRM: ['Tecnología', 'Estados Unidos'], ADBE: ['Tecnología', 'Estados Unidos'],
        GOOGL: ['Comunicación', 'Estados Unidos'], META: ['Comunicación', 'Estados Unidos'], DIS: ['Comunicación', 'Estados Unidos'], NFLX: ['Comunicación', 'Estados Unidos'], T: ['Comunicación', 'Estados Unidos'], VZ: ['Comunicación', 'Estados Unidos'],
        AMZN: ['Consumo discrecional', 'Estados Unidos'], TSLA: ['Consumo discrecional', 'Estados Unidos'], MCD: ['Consumo discrecional', 'Estados Unidos'], NKE: ['Consumo discrecional', 'Estados Unidos'], UBER: ['Industriales', 'Estados Unidos'],
        KO: ['Consumo básico', 'Estados Unidos'], PEP: ['Consumo básico', 'Estados Unidos'], WMT: ['Consumo básico', 'Estados Unidos'], COST: ['Consumo básico', 'Estados Unidos'],
        JPM: ['Finanzas', 'Estados Unidos'], BAC: ['Finanzas', 'Estados Unidos'], V: ['Finanzas', 'Estados Unidos'], MA: ['Finanzas', 'Estados Unidos'], PYPL: ['Finanzas', 'Estados Unidos'], COIN: ['Finanzas', 'Estados Unidos'], BRKB: ['Finanzas', 'Estados Unidos'],
        XOM: ['Energía', 'Estados Unidos'], CVX: ['Energía', 'Estados Unidos'], PFE: ['Salud', 'Estados Unidos'], JNJ: ['Salud', 'Estados Unidos'], BA: ['Industriales', 'Estados Unidos'], MSTR: ['Tecnología', 'Estados Unidos'],
        MELI: ['Consumo discrecional', 'Uruguay'], SHOP: ['Tecnología', 'Canadá'], SPOT: ['Comunicación', 'Luxemburgo'], TSM: ['Tecnología', 'Taiwán'], ASML: ['Tecnología', 'Países Bajos'], SAP: ['Tecnología', 'Alemania'], BABA: ['Consumo discrecional', 'China'], VALE: ['Materiales', 'Brasil'], PBR: ['Energía', 'Brasil'], ITUB: ['Finanzas', 'Brasil'], ITUB1: ['Finanzas', 'Brasil'], GOLD: ['Materiales', 'Canadá'], NEM: ['Materiales', 'Estados Unidos'],
        YPF: ['Energía', 'Argentina'], GGAL: ['Finanzas', 'Argentina'], BMA: ['Finanzas', 'Argentina'], PAM: ['Servicios públicos', 'Argentina'], TEO: ['Comunicación', 'Argentina'], VIST: ['Energía', 'México'],
        SPY: ['Diversificado', 'Estados Unidos'], QQQ: ['Diversificado', 'Estados Unidos'], DIA: ['Diversificado', 'Estados Unidos'], IWM: ['Diversificado', 'Estados Unidos'], EEM: ['Diversificado', 'Mercados emergentes'], EWZ: ['Diversificado', 'Brasil'], VEA: ['Diversificado', 'Mercados desarrollados'], ARKK: ['Diversificado', 'Diversificado'], IBIT: ['Criptoactivos', 'Sin clasificar'], XLE: ['Energía', 'Estados Unidos'], XLF: ['Finanzas', 'Estados Unidos'], XLK: ['Tecnología', 'Estados Unidos'], XLV: ['Salud', 'Estados Unidos'],
    };
    const groupDistribution = (key: (i: Investment) => string) => {
        const groups = new Map<string, Investment[]>();
        items.forEach(i => { const label = key(i); groups.set(label, [...(groups.get(label) ?? []), i]); });
        return [...groups].map(([label, list], index) => ({ label, color: palette[index % palette.length], value: valueOf(list), count: list.length }));
    };
    const byAsset = groupDistribution(i => i.kind === 'rate' ? i.name : `${titleFor(i.kind)} · ${i.coin?.split('~')[0]}`);
    const bySector = groupDistribution(i => i.kind === 'crypto' ? 'Criptomonedas' : i.kind === 'cedear' || i.kind === 'stock' ? classifications[i.coin ?? '']?.[0] ?? 'Sin clasificar' : 'Sin clasificar');
    const countryOf = (i: Investment) => i.kind === 'crypto' ? 'Sin país asociado' : i.kind === 'cedear' || i.kind === 'stock' ? classifications[i.coin ?? '']?.[1] ?? 'Sin clasificar' : 'Sin clasificar';
    const byCountry = groupDistribution(countryOf);
    const mapPositions = items.map(investment => ({ investment, country: countryOf(investment), value: fx(valueAt(investment, today, prices, today, officialRate), investment.currency) }));
    const makeChart = (chartItems: Investment[], chartCurrent: number) => {
        if (!chartItems.length || !Number.isFinite(chartCurrent) || !fxRate && chartItems.some(i => i.currency !== display)) return null;
        const earliest = Math.min(today, ...chartItems.map(i => dateMillis(i.date)));
        const days = { '7d': 7, '1m': 30, '6m': 182, '1a': 365 };
        const start = range === 'todo' ? Math.min(earliest, today - 86400000) : today - days[range] * 86400000;
        const end = today;
        const len = 72, w = 850, h = 230, pad = 12;
        const samples = Array.from({ length: len + 1 }, (_, idx) => { const t = start + (end - start) * idx / len; return { t, value: chartItems.reduce((s, i) => s + fx(valueAt(i, t, prices, today, officialRate), i.currency), 0) }; });
        const max = Math.max(1, ...samples.map(s => s.value)) * 1.12;
        const px = (t: number) => pad + (t - start) / (end - start || 1) * (w - 2 * pad);
        const py = (v: number) => h - pad - v / max * (h - 2 * pad);
        const line = samples.map((s, i) => `${i ? 'L' : 'M'} ${px(s.t).toFixed(1)} ${py(s.value).toFixed(1)}`).join(' ');
        const baseline = h - pad;
        const area = `${line} L ${px(end)} ${baseline} L ${px(start)} ${baseline} Z`;
        const nowX = Math.min(w - pad, px(today));
        return { w, h, line, area, nowX, nowY: py(chartCurrent), first: chartDate(start), points: samples.map(sample => ({ ...sample, x: px(sample.t), y: py(sample.value) })) };
    };
    const chart = makeChart(items, current);
    const summaryChart = hiddenSummaryKinds.length ? makeChart(summaryItems, summaryCurrent) : chart;
    const [temporaryBenchmark, setTemporaryBenchmark] = useState<PickedAsset | LocalSelection | null>(null);
    const [benchmarkSearchOpen, setBenchmarkSearchOpen] = useState(false);
    const [benchmarkSearchStatus, setBenchmarkSearchStatus] = useState('');
    const benchmarkSearchRequest = useRef(0);
    const [benchmarkHistory, setBenchmarkHistory] = useState<Record<string, HistoryPoint[]> | null>(null);
    const [benchmarkHistoryError, setBenchmarkHistoryError] = useState('');
    const temporaryKey = temporaryBenchmark ? `${temporaryBenchmark.kind === 'index' ? 'stock' : temporaryBenchmark.kind}:${temporaryBenchmark.id}` : '';
    const historySignature = [...new Set([...items.filter(i => i.kind !== 'rate' && i.coin).map(i => `${i.kind}:${i.coin}`), ...(temporaryKey ? [temporaryKey] : [])])].sort().join('|');
    const needsDollarHistory = items.some(i => i.kind === 'crypto' || i.currency === 'USD') || (temporaryBenchmark?.kind === 'crypto' || temporaryBenchmark?.kind === 'stock' || temporaryBenchmark?.kind === 'index');
    useEffect(() => {
        if (page !== 'evolution') return;
        const controller = new AbortController();
        setBenchmarkHistory(null); setBenchmarkHistoryError('');
        const keys = historySignature ? historySignature.split('|') : [];
        const assetRequests = keys.map(async key => {
            const [assetKind, id] = key.split(':');
            try {
                const points = await history(assetKind as 'cedear' | 'crypto' | 'stock' | 'arg-stock' | 'bond' | 'fund', id, controller.signal);
                return [key, (assetKind === 'cedear' || assetKind === 'arg-stock') ? adjustPossibleRatios(points).points : points] as const;
            } catch { return [key, []] as const; }
        });
        const dollarRequest = needsDollarHistory ? fetch('https://api.argentinadatos.com/v1/cotizaciones/dolares/bolsa', { signal: AbortSignal.any([controller.signal, AbortSignal.timeout(20000)]) }).then(async response => {
            if (!response.ok) throw new Error('No se pudo consultar el historial del dólar MEP.');
            const rows: unknown = await response.json();
            if (!Array.isArray(rows)) throw new Error('El historial del dólar no está disponible.');
            const points: HistoryPoint[] = rows.flatMap(row => {
                const time = Date.parse(`${String(row?.fecha ?? '').slice(0, 10)}T12:00:00Z`), price = Number(row?.venta);
                return Number.isFinite(time) && Number.isFinite(price) && price > 0 ? [{ time, price }] : [];
            }).sort((a, b) => a.time - b.time);
            if (!points.length) throw new Error('El historial del dólar no está disponible.');
            return ['dollar:mep', points] as const;
        }).catch(() => null) : Promise.resolve(null);
        void Promise.all([Promise.all(assetRequests), dollarRequest]).then(([entries, dollar]) => {
            if (!controller.signal.aborted) setBenchmarkHistory(Object.fromEntries(dollar ? [...entries, dollar] : entries));
        }).catch(() => { if (!controller.signal.aborted) { setBenchmarkHistoryError('No se pudo obtener el historial de todos tus activos o del dólar. Volvé a intentar más tarde.'); setBenchmarkHistory({}); } });
        return () => controller.abort();
    }, [page, historySignature, needsDollarHistory]);
    const [benchmarkSelection, setBenchmarkSelection] = useState('all');
    const [benchmarkMonths, setBenchmarkMonths] = useState(12);
    const benchmarkOptions = [...new Map(items.map(i => {
        const key = i.kind === 'rate' ? `rate:${i.id}` : `${i.kind}:${i.coin}`;
        return [key, { value: key, label: i.kind === 'cedear' ? `${i.name} · ${i.coin}` : i.name }] as const;
    })).values()];
    const temporarySelected = benchmarkSelection === 'temporary' && temporaryBenchmark !== null;
    const selectedBenchmark = temporarySelected ? { value: 'temporary', label: temporaryBenchmark.name } : benchmarkOptions.find(option => option.value === benchmarkSelection);
    const startForMonths = (months: number) => {
        const date = new Date(today);
        const day = date.getDate();
        date.setDate(1);
        date.setMonth(date.getMonth() - months);
        date.setDate(Math.min(day, new Date(date.getFullYear(), date.getMonth() + 1, 0).getDate()));
        return date.getTime();
    };
    const yearDate = new Date(today);
    yearDate.setFullYear(yearDate.getFullYear() - 1);
    const yearStart = yearDate.getTime();
    const selectTemporaryBenchmark = async (asset: PickedAsset | LocalSelection) => {
        const requestId = ++benchmarkSearchRequest.current;
        setBenchmarkSearchOpen(false);
        setBenchmarkSearchStatus(`Consultando el historial de ${asset.name}…`);
        try {
            const kind = asset.kind === 'index' ? 'stock' : asset.kind;
            const raw = await history(kind, asset.id, new AbortController().signal);
            const points = kind === 'cedear' ? adjustPossibleRatios(raw).points : raw;
            const last = points.at(-1);
            const coversYear = !!last && today - last.time <= 7 * 86400000 && Array.from({ length: 241 }, (_, index) => yearStart + (today - yearStart) * index / 240).every(t => {
                const previous = points.filter(point => point.time <= t).at(-1);
                return previous ? t - previous.time <= 7 * 86400000 : points[0].time - t <= 3 * 86400000;
            });
            if (requestId !== benchmarkSearchRequest.current) return;
            if (!coversYear) {
                setBenchmarkSearchStatus(`${asset.name} no tiene historial anual suficiente para compararlo.`);
                return;
            }
            setTemporaryBenchmark(asset);
            setBenchmarkSelection('temporary');
            setBenchmarkSearchStatus('');
        } catch {
            if (requestId === benchmarkSearchRequest.current) setBenchmarkSearchStatus(`No se pudo consultar el historial de ${asset.name}. Probá nuevamente.`);
        }
    };
    const benchmarkItems = selectedBenchmark ? items.filter(i => (i.kind === 'rate' ? `rate:${i.id}` : `${i.kind}:${i.coin}`) === selectedBenchmark.value) : items;
    const annualPriceAt = (points: HistoryPoint[] | undefined, t: number, currentPrice: number) => {
        if (!points?.length) return NaN;
        if (t >= today - 60000) return today - points[points.length - 1].time <= 7 * 86400000 ? currentPrice : NaN;
        let previous: HistoryPoint | undefined;
        for (const point of points) { if (point.time > t) break; previous = point; }
        if (previous && t - previous.time <= 7 * 86400000) return previous.price;
        if (!previous && points[0].time - t <= 3 * 86400000) return points[0].price;
        return NaN;
    };
    const benchmarkDollarAt = (t: number) => {
        if (!fxRate) return NaN;
        const points = benchmarkHistory?.['dollar:mep'];
        const latest = points?.length && today - points[points.length - 1].time <= 7 * 86400000 ? points[points.length - 1].price : NaN;
        const historical = t >= today - 60000 ? latest : annualPriceAt(points, t, fxRate);
        return Number.isFinite(latest) && Number.isFinite(historical) ? fxRate * historical / latest : NaN;
    };
    const benchmarkValue = (t: number) => {
        if (temporarySelected) {
            const points = benchmarkHistory?.[temporaryKey];
            const latest = points?.at(-1)?.price;
            const price = latest ? annualPriceAt(points, t, latest) : NaN;
            return ['cedear', 'arg-stock', 'bond', 'fund'].includes(temporaryBenchmark.kind) ? price : price * benchmarkDollarAt(t);
        }
        return benchmarkItems.reduce((sum, i) => {
            if (i.kind === 'rate') {
                const present = valueAt(i, today, prices, today, fxRate);
                const historical = i.maturityDate ? valueAt(i, t, prices, today, fxRate) : present * Math.pow(1 + monthlyRate(i), (t - today) / MONTH_MS);
                return sum + (i.currency === 'ARS' ? historical : historical * benchmarkDollarAt(t));
            }
            const key = `${i.kind}:${i.coin}`;
            const currentPrice = prices[key];
            const historicalPrice = currentPrice ? annualPriceAt(benchmarkHistory?.[key], t, currentPrice) : NaN;
            if (!currentPrice || !historicalPrice || !i.units) return NaN;
            if (i.kind === 'cedear' || isLocal(i)) return sum + i.units * historicalPrice;
            return sum + i.units * historicalPrice * benchmarkDollarAt(t);
        }, 0);
    };
    const benchmarkUnitPrice = (t: number) => {
        if (!selectedBenchmark || temporarySelected) return undefined;
        const item = benchmarkItems[0];
        if (!item || item.kind === 'rate') return undefined;
        const key = `${item.kind}:${item.coin}`;
        const currentPrice = prices[key];
        if (!currentPrice) return undefined;
        const historicalPrice = annualPriceAt(benchmarkHistory?.[key], t, currentPrice);
        return item.kind === 'cedear' || isLocal(item) ? historicalPrice : historicalPrice * benchmarkDollarAt(t);
    };
    const periods = [1, 6, 12, 24, 36, 72];
    const canCheckPeriods = benchmarkHistory !== null && !benchmarkHistoryError && (temporarySelected || benchmarkItems.length > 0);
    const availablePeriods = canCheckPeriods ? periods.filter(months => {
        const start = startForMonths(months);
        return Array.from({ length: 241 }, (_, index) => benchmarkValue(start + (today - start) * index / 240))
            .every(value => Number.isFinite(value) && value > 0);
    }) : periods;
    const effectiveMonths = availablePeriods.includes(benchmarkMonths) ? benchmarkMonths
        : availablePeriods.filter(months => months < benchmarkMonths).at(-1) ?? availablePeriods[0] ?? 1;
    const benchmarkStart = startForMonths(effectiveMonths);
    const monthlyDates = Array.from({ length: 13 }, (_, index) => {
        const endDate = new Date(today);
        const desiredDay = endDate.getDate();
        endDate.setDate(1);
        endDate.setMonth(endDate.getMonth() - (12 - index));
        const daysInMonth = new Date(endDate.getFullYear(), endDate.getMonth() + 1, 0).getDate();
        endDate.setDate(Math.min(desiredDay, daysInMonth));
        return endDate.getTime();
    });
    const hasObservation = (points: HistoryPoint[] | undefined, timestamp: number) => {
        if (!points?.length) return false;
        const previous = points.filter(point => point.time <= timestamp).at(-1);
        if (previous && timestamp - previous.time <= 7 * 86400000) return true;
        return !previous && points[0].time - timestamp <= 3 * 86400000;
    };
    const monthlyHistoryAvailable = temporarySelected
        ? monthlyDates.every(t => hasObservation(benchmarkHistory?.[temporaryKey], t)) && (['cedear', 'arg-stock', 'bond', 'fund'].includes(temporaryBenchmark.kind) || monthlyDates.every(t => hasObservation(benchmarkHistory?.['dollar:mep'], t)))
        : benchmarkItems.length > 0 && benchmarkItems.every(i => {
            if (i.kind === 'rate' || !i.coin) return false;
            const points = benchmarkHistory?.[`${i.kind}:${i.coin}`];
            return monthlyDates.every(t => hasObservation(points, t)) && (i.kind !== 'crypto' || monthlyDates.every(t => hasObservation(benchmarkHistory?.['dollar:mep'], t)));
        });
    const monthlyValues = monthlyHistoryAvailable ? monthlyDates.map(benchmarkValue) : [];
    const averageMonthlyReturn = monthlyValues.length === 13 && monthlyValues.every(v => Number.isFinite(v) && v > 0)
        ? monthlyValues.slice(1).reduce((sum, value, index) => sum + (value / monthlyValues[index] - 1) * 100, 0) / 12
        : null;
    // El resultado de las posiciones abiertas usa la fecha de cada registro.
    const costInPesos = benchmarkItems.reduce((sum, i) => {
        if (i.costUnknown) return NaN;
        if (i.currency === 'ARS') return sum + i.amount;
        const points = benchmarkHistory?.['dollar:mep'];
        const purchaseTime = dateMillis(i.date) + 12 * 3600000;
        const purchaseQuote = points?.filter(p => p.time <= purchaseTime).at(-1);
        if (!purchaseQuote || purchaseTime - purchaseQuote.time > 7 * 86400000) return NaN;
        return sum + i.amount * purchaseQuote.price;
    }, 0);
    const currentInPesos = benchmarkItems.reduce((sum, i) => {
        if (i.kind !== 'rate' && (!i.coin || !prices[`${i.kind}:${i.coin}`])) return NaN;
        const v = valueAt(i, today, prices, today, fxRate);
        return sum + (i.currency === 'ARS' ? v : v * (fxRate ?? NaN));
    }, 0);
    const actualReturnArs = costInPesos > 0 && Number.isFinite(currentInPesos) ? (currentInPesos / costInPesos - 1) * 100 : null;
    const chartPoint = chartIndex == null ? null : chart?.points[chartIndex] ?? null;
    const pickKind = (k: Kind) => { if (k === kind && !indexMode) return; setIndexMode(false); setKind(k); if (k === 'cedear') setCurrency('ARS'); else if (k === 'stock') setCurrency('USD'); setCoin(k === 'cedear' || k === 'stock' ? 'AAPL' : 'bitcoin'); setAssetQuote(null); setError(''); };
    function openModal() {
        setSelectedAsset(null); setLocalConfirmed(false); setKind('rate');
        setPriceMode('current'); setPurchasePrice('');
        setError(''); setEditingId(null); setName(''); setAmount(''); setRate(''); setDepositMaturity(''); setDate(localISO());
        setIndexMode(false); setAssetQuote(null); setModal(true);
    }
    function openEdit(i: Investment) {
        setSelectedAsset(null);
        setPriceMode('current'); setPurchasePrice('');
        setError(''); setEditingId(i.id); setIndexMode((i.kind === 'cedear' || i.kind === 'stock') && isIndexTicker(i.coin)); setKind(i.kind); setName(i.name); setAmount(i.costUnknown ? '' : String(i.amount)); setDate(i.costUnknown ? '' : i.date);
        setCurrency(i.currency); setRate(i.rate != null ? String(i.rate) : ''); setPeriod(i.period ?? 'year'); setDepositMaturity(i.maturityDate ?? '');
        setCoin(i.coin ?? (i.kind === 'cedear' ? 'AAPL' : 'bitcoin'));
        setAssetQuote(null); setQuoteRequest(v => v + 1); setModal(true);
    }
    function closeModal() { setModal(false); setEditingId(null); }
    function selectLocalAsset(asset: LocalSelection) {
        setSelectedAsset(null); setLocalConfirmed(false); setIndexMode(false); setKind(asset.kind); setCurrency('ARS'); setCoin(asset.id); setName(asset.name.slice(0, 70)); setAmount(''); setPriceMode('current'); setPurchasePrice(''); setDate(localISO()); setEditingId(null); setError('');
        setAssetQuote({ id: asset.id, date: todayDate, kind: asset.kind, status: 'ready', price: asset.price, sourceDate: asset.sourceDate });
        setAssetSearch(null); setInitialLocalSearch(undefined); setModal(true);
    }
    function selectAsset(asset: PickedAsset) {
        setSelectedAsset(asset);
        const isIndex = asset.kind === 'index';
        setIndexMode(isIndex); setKind(asset.kind === 'stock' || (isIndex && kind === 'stock') ? 'stock' : asset.kind === 'crypto' ? 'crypto' : 'cedear'); if (isIndex || asset.kind === 'stock') setCurrency('USD'); else if (asset.kind !== 'crypto') setCurrency('ARS'); setCoin(asset.id); setName(asset.name.slice(0, 70));
        setAssetQuote(null); setQuoteRequest(value => value + 1); setError(''); setAssetSearch(null); setInitialLocalSearch(undefined); setModal(true);
    }
    function duplicate(i: Investment) { setItems(prev => [...prev, { ...i, id: crypto.randomUUID(), name: `${i.name} (copia)`.slice(0, 70) }]); setNotice('Inversión duplicada.'); }
    function add(e: FormEvent<HTMLFormElement>) {
        e.preventDefault(); setError('');
        const value = Number(amount); const todayDate = localISO();
        if ((kind === 'rate' && !name.trim()) || !Number.isFinite(value) || value <= 0) return setError('Ingresá un nombre y un monto válido mayor a cero.');
        if (!date || date > todayDate || !Number.isFinite(dateMillis(date))) return setError('Ingresá una fecha válida que no sea futura.');
        const cur: Currency = currency;
        const id = kind === 'crypto' || kind === 'fund' ? coin.trim().toLowerCase() : coin.trim().toUpperCase();
        const selectedName = selectedAsset && selectedAsset.id === id && (selectedAsset.kind === kind || (selectedAsset.kind === 'index' && kind === 'cedear')) ? selectedAsset.name : '';
        const fallbackName = indexMode ? `${indexName(id)} (${id})` : selectedName || (kind !== 'crypto' ? cedearName(id) : '') || id;
        const investment: Investment = { id: editingId ?? crypto.randomUUID(), name: (name.trim() || fallbackName).slice(0, 70), amount: value, currency: cur, date, kind };
        if (kind === 'rate') {
            const r = Number(rate);
            if (!rate.trim() || !Number.isFinite(r) || r <= -100) return setError('Ingresá una tasa válida superior a -100%.');
            if (depositMaturity && (r < 0 || period !== 'year' || depositMaturity <= date || !Number.isFinite(dateMillis(depositMaturity)))) return setError('Para el plazo fijo, elegí una tasa anual no negativa y una fecha de vencimiento posterior al inicio.');
            investment.rate = r; investment.period = period; if (depositMaturity) investment.maturityDate = depositMaturity;
        } else {
            const id = kind === 'crypto' || kind === 'fund' ? coin.trim().toLowerCase() : coin.trim().toUpperCase();
            if ((kind === 'arg-stock' || kind === 'bond' || kind === 'fund') && !localConfirmed) return setError('Confirmá que la especie y el precio corresponden a pesos.');
            if (!id) return setError('Ingresá el ticker o identificador del activo.');
            const original = editingId ? items.find(item => item.id === editingId) : undefined;
            if (original?.costUnknown && (kind !== original.kind || id !== original.coin || currency !== original.currency)) return setError('Para completar el costo, conservá el activo y la moneda de la posición importada.');
            const unchangedPosition = original && original.kind === kind && original.coin === id && original.amount === value && original.currency === currency && original.date === date && priceMode === 'current';
            if (!unchangedPosition && !original?.costUnknown && (!selectedPrice || !Number.isFinite(selectedPrice) || selectedPrice <= 0)) return setError(priceMode === 'purchase' ? 'Ingresá un precio de compra por unidad válido.' : 'Esperá a que se consulte la cotización actual.');
            if (!unchangedPosition && currency !== quoteCurrency && !fxRate) return setError('No está disponible la cotización de USDC para convertir el monto.');
            investment.coin = id; investment.units = original?.costUnknown ? original.units : unchangedPosition ? original.units : convertedAmount / selectedPrice!;
            if (investment.units == null || !Number.isFinite(investment.units) || investment.units <= 0) return setError('El monto es demasiado grande o pequeño para calcular las unidades.');
            if (original?.costUnknown) investment.purchasePrice = value / investment.units;
            else if (unchangedPosition) { investment.purchasePrice = original.purchasePrice; investment.purchaseFx = original.purchaseFx; }
            else if (priceMode === 'purchase') { investment.purchasePrice = selectedPrice; if (currency !== quoteCurrency && fxRate) investment.purchaseFx = fxRate; }
            if (activeQuote?.status === 'ready') setPrices(prev => ({ ...prev, [`${kind}:${id}`]: activeQuote.price }));
        }
        setItems(prev => editingId ? prev.map(x => x.id === editingId ? investment : x) : [...prev, investment]);
        setNotice(editingId ? 'Inversión actualizada.' : '');
        setName(''); setAmount(''); setRate(''); setModal(false); setEditingId(null);
    }
    async function exportJSON() {
        const data = {
            version: 2,
            exportedAt: new Date().toISOString(),
            investments: items,
            sales: view.portfolio.sales ?? [],
            preferences: view.portfolio.preferences,
        };

        const file = new File(
            [JSON.stringify(data, null, 2)],
            `inversiones-${localISO()}.json`,
            { type: "application/json" }
        );

        // Compartir archivo mediante el menú nativo
        if (navigator.canShare?.({ files: [file] })) {
            try {
                await navigator.share({
                    files: [file],
                    title: "Mis inversiones",
                    text: "Exportación de inversiones",
                });

                return;
            } catch (error) {
                if (error instanceof Error && error.name === "AbortError") {
                    return;
                }

                console.error("Error al compartir:", error);
            }
        }

        // Alternativa: descargar el JSON
        const url = URL.createObjectURL(file);
        const a = document.createElement("a");

        a.href = url;
        a.download = file.name;
        a.click();

        setTimeout(() => URL.revokeObjectURL(url), 1000);
    }
    async function onImportFile(e: ChangeEvent<HTMLInputElement>) {
        const file = e.target.files?.[0];
        e.target.value = ''; // permite volver a elegir el mismo archivo
        if (!file) return;
        try {
            if (file.size > 2_000_000) throw new Error('size');
            const data = JSON.parse(await file.text());
            const list = Array.isArray(data) ? data : data?.investments;
            if (!Array.isArray(list)) throw new Error('format');
            const seen = new Set<string>(); const valid: Investment[] = [];
            for (const raw of list.slice(0, 5000)) {
                const inv = cleanInvestment(raw);
                if (inv && !seen.has(inv.id)) { seen.add(inv.id); valid.push(inv); }
            }
            const sales: Sale[] = [];
            const saleIds = new Set<string>();
            if (Array.isArray(data?.sales)) for (const raw of data.sales.slice(0, 10000)) {
                const sale = cleanSale(raw);
                if (sale && !saleIds.has(sale.id)) { saleIds.add(sale.id); sales.push(sale); }
            }
            if (!valid.length && !sales.length) { setNotice('El archivo no contiene inversiones ni ventas válidas.'); return; }
            setImportPreview({ items: valid, sales, skipped: list.length - valid.length + (Array.isArray(data?.sales) ? data.sales.length - sales.length : 0) });
        } catch {
            setNotice('No se pudo leer el archivo. Elegí un JSON exportado desde esta app (máx. 2 MB).');
        }
    }
    function applyImport(mode: 'merge' | 'replace') {
        if (!importPreview) return;
        const incoming = importPreview.items;
        if (mode === 'replace') {
            sync.update(current => ({ ...current, investments: incoming, sales: importPreview.sales }));
            setNotice(`Cartera reemplazada: ${incoming.length} inversiones importadas.`);
        } else {
            const ids = new Set(items.map(i => i.id));
            const fresh = incoming.filter(i => !ids.has(i.id));
            const dup = incoming.length - fresh.length;
            sync.update(current => {
                const saleIds = new Set((current.sales ?? []).map(sale => sale.id));
                return { ...current, investments: [...current.investments, ...fresh], sales: [...(current.sales ?? []), ...importPreview.sales.filter(sale => !saleIds.has(sale.id))] };
            });
            setNotice(`Se agregaron ${fresh.length} inversiones${dup ? ` (${dup} ya existían y se omitieron)` : ''}.`);
        }
        setImportPreview(null);
    }
    async function logout() {
        if (leaving) return;
        setLeaving(true);
        try {
            if (!await sync.flush()) return;
            await request('logout', 'POST', {});
            onLogout();
        } catch (error) { setNotice(error instanceof Error ? error.message : 'No se pudo cerrar la sesión.'); }
        finally { setLeaving(false); }
    }
    async function importLegacy() {
        if (!legacy) return;
        sync.update(current => {
            const ids = new Set(current.investments.map(item => item.id));
            return { ...current, investments: [...current.investments, ...legacy.investments.filter(item => !ids.has(item.id))], preferences: current.investments.length ? current.preferences : legacy.preferences };
        });
        if (await sync.flush()) {
            try { localStorage.setItem('inversiones:migrated-to', account.user.id); } catch { /* El respaldo original permanece disponible. */ }
            setLegacy(null);
            setNotice('Las inversiones de este navegador ya están guardadas en tu cuenta.');
        }
    }
    async function reloadPortfolio() {
        if (view.dirty && !window.confirm('Se van a descartar los cambios pendientes de esta pestaña y cargar la cartera guardada. Podés exportarlos antes de continuar. ¿Querés recargar?')) return;
        try { sync.reset(await request<Snapshot>('portfolio')); }
        catch (error) { setNotice(error instanceof Error ? error.message : 'No se pudo cargar tu cartera.'); }
    }
    const syncLabel = view.status === 'saved' ? 'Guardado en tu cuenta' : view.status === 'saving' ? 'Guardando…' : view.status === 'pending' ? 'Cambios pendientes' : 'Sin guardar';
    const goTo = (path: string) => { window.history.pushState(null, '', path); window.dispatchEvent(new PopStateEvent('popstate')); };
    const cryptoSymbols: Record<string, string> = { bitcoin: 'BTC', ethereum: 'ETH', solana: 'SOL', tether: 'USDT', 'usd-coin': 'USDC', ripple: 'XRP', binancecoin: 'BNB', dogecoin: 'DOGE', cardano: 'ADA' };
    const tickerOf = (i: Investment) => i.kind === 'rate' ? 'TASA' : i.kind !== 'crypto' ? (i.coin ?? '').slice(0, 5) : (cryptoSymbols[i.coin ?? ''] ?? (i.coin ?? '').slice(0, 4).toUpperCase());
    const summaryOf = (i: Investment) => { const v = valueAt(i, today, prices, today, officialRate); return `${i.name} · ${titleFor(i.kind)} · ${i.costUnknown ? 'costo desconocido' : `invertido ${money(i.amount, i.currency)}`} · hoy ${Number.isFinite(v) ? money(v, i.currency) : '—'}${!i.costUnknown && Number.isFinite(v) ? ` (${percent((v - i.amount) / i.amount * 100)})` : ''}`; };
    const copySummary = async (i: Investment) => { try { await navigator.clipboard.writeText(summaryOf(i)); setNotice('Resumen copiado al portapapeles.'); } catch { setNotice('No se pudo copiar. Tu navegador bloqueó el portapapeles.'); } };
    const menuFor = (i: Investment): MenuItem[] => [
        { label: 'Registrar venta', icon: Estimate01Icon, onSelect: () => openSale(i) },
        ...(!isLocal(i) ? [{ label: 'Editar', icon: Edit01Icon, onSelect: () => openEdit(i) }] : []),
        { label: 'Duplicar', icon: CopyPlusIcon, onSelect: () => duplicate(i) },
        { label: 'Copiar resumen', icon: Copy01Icon, onSelect: () => void copySummary(i) },
        ...(i.kind === 'crypto' && i.coin ? [{ label: 'Ver en CoinGecko', icon: LinkSquare02Icon, href: `https://www.coingecko.com/en/coins/${encodeURIComponent(i.coin)}` }] : []),
        ...(i.kind === 'cedear' && i.coin ? [{ label: 'Ver dividendos', icon: Estimate01Icon, onSelect: () => goTo('/dividendos') }, { label: 'Ver en Data912', icon: LinkSquare02Icon, href: `https://data912.com/historical/cedears/${encodeURIComponent(i.coin)}` }] : []),
        { sep: true },
        { label: 'Eliminar', icon: Delete02Icon, danger: true, onSelect: () => setConfirmDelete(i.id) },
    ] as MenuItem[];
    function openSale(item: Investment) {
        if (item.costUnknown) { setNotice('Para registrar una venta, primero editá la inversión y completá su costo de compra.'); return; }
        const hasQuote = item.kind === 'rate' || !!(item.coin && prices[`${item.kind}:${item.coin}`] != null);
        const currentValue = hasQuote ? valueAt(item, today, prices, today, officialRate) : NaN;
        const initial = item.kind === 'rate' ? currentValue : item.units ? currentValue / item.units : NaN;
        setSellId(item.id); setSellPercent('100'); setSellInputMode('percent'); setSellInputAmount(''); setSellCurrency(item.currency); setSellError(''); setSellFee('0');
        setSellExecutionPrice(!hidden && Number.isFinite(initial) && initial > 0 ? String(initial) : '');
    }

  
    const sellItem = items.find(item => item.id === sellId);
    const sellPrice = Number(sellExecutionPrice);
    const sellTotal = sellItem && Number.isFinite(sellPrice) && sellPrice > 0 ? sellItem.kind === 'rate' ? sellPrice : (sellItem.units ?? 0) * sellPrice : NaN;
    const sellFraction = sellInputMode === 'percent' ? Number(sellPercent) / 100 : Number(sellInputAmount) / sellTotal;
    const sellGross = sellInputMode === 'percent' ? sellTotal * sellFraction : Number(sellInputAmount);
    const sellCommission = sellFee.trim() === '' ? 0 : Number(sellFee);
    const sellNet = sellGross - sellCommission;
    function registerSale() {
        if (!sellItem || !Number.isFinite(sellTotal) || sellTotal <= 0) return setSellError(sellItem?.kind === 'rate' ? 'Ingresá el valor bruto total de la posición.' : 'Ingresá un precio ejecutado mayor a cero.');
        const fraction = sellFraction;
        if (!Number.isFinite(fraction) || fraction <= 0 || fraction > 1 || !Number.isFinite(sellGross) || sellGross <= 0) return setSellError(sellInputMode === 'percent' ? 'Ingresá un porcentaje mayor a 0 y hasta 100.' : 'Ingresá un importe bruto mayor a 0 que no supere el valor total de la posición.');
        if (!Number.isFinite(sellCommission) || sellCommission < 0 || sellCommission >= sellGross) return setSellError('La comisión debe ser mayor o igual a cero y menor al importe bruto.');
        const sale: Sale = { id: crypto.randomUUID(), name: sellItem.name, date: localISO(), fraction, proceeds: sellNet, currency: sellCurrency, cost: sellItem.amount * fraction, costCurrency: sellItem.currency, fee: sellCommission, ...(sellItem.kind === 'rate' ? {} : { executionPrice: sellPrice, units: sellItem.units! * fraction }) };
        sync.update(current => ({ ...current, sales: [...(current.sales ?? []), sale], investments: current.investments.flatMap(item => item.id !== sellItem.id ? [item] : fraction === 1 ? [] : [{ ...item, amount: item.amount * (1 - fraction), ...(item.units == null ? {} : { units: item.units * (1 - fraction) }) }]) }));
        setSellId(null); setNotice('Venta registrada con el importe neto. No se suma como efectivo a la cartera.');
    }
    const ctxItem = ctx ? items.find(i => i.id === ctx.id) : undefined;
    const capShare = !Number.isFinite(summaryGain) ? 1 : summaryGain >= 0 ? (summaryCurrent > 0 ? summaryInvested / summaryCurrent : 1) : (summaryInvested > 0 ? summaryCurrent / summaryInvested : 1);
    const slicesForBar = byKind.filter(k => !hiddenSummaryKinds.includes(k.id) && Number.isFinite(k.value) && k.value > 0);
    const slicesTotal = slicesForBar.reduce((s, k) => s + k.value, 0);
    const statusDot = view.status === 'saved' ? 'live' : 'live warn';
    const compare = compareOrder.filter(k => rates[k]);
    useEffect(() => {
        const onKey = (event: KeyboardEvent) => {
            const target = event.target as HTMLElement | null;
            if (event.key !== '/' || event.metaKey || event.ctrlKey || event.altKey || target?.closest('input, textarea, select, [contenteditable], [role=dialog], [role=menu]')) return;
            event.preventDefault(); setInitialLocalSearch(undefined); setAssetSearch('crypto');
        };
        window.addEventListener('keydown', onKey);
        return () => window.removeEventListener('keydown', onKey);
    }, []);
    const detailItem = detailId ? items.find(i => i.id === detailId) : undefined;
    const locked = !!assetSearch || !!sellItem || !!detailItem || panelEditor || emailSettings || leaving;
    const panelOrder = (id: string) => { const index = visiblePanels.indexOf(id); return index < 0 ? 99 : index; };
    const mainRef = useRef<HTMLElement>(null);
    useEffect(() => {
        if (window.matchMedia('(prefers-reduced-motion: reduce)').matches) return;
        const animation = mainRef.current?.animate(
            [{ opacity: .7, transform: 'translateY(6px)' }, { opacity: 1, transform: 'translateY(0)' }],
            { duration: 240, easing: 'ease-out' },
        );
        return () => animation?.cancel();
    }, [page]);
    useEffect(() => {
        const root = mainRef.current;
        if (!root || window.matchMedia('(prefers-reduced-motion: reduce)').matches || !('IntersectionObserver' in window)) return;
        const observed = new WeakSet<Element>();
        const observer = new IntersectionObserver(entries => {
            entries.forEach(entry => entry.target.classList.toggle('chart-visible', entry.isIntersecting));
        }, { threshold: .15 });
        const observeCharts = () => root.querySelectorAll('.chart-animate').forEach(element => {
            if (!observed.has(element)) { observed.add(element); observer.observe(element); }
        });
        observeCharts();
        const mutations = new MutationObserver(observeCharts);
        mutations.observe(root, { childList: true, subtree: true });
        return () => { mutations.disconnect(); observer.disconnect(); };
    }, []);
    return <div data-theme={resolvedTheme} className="app min-h-dvh [&_input[type=date]]:[color-scheme:dark] data-[theme=light]:[&_input[type=date]]:[color-scheme:light]">
        <input ref={fileRef} type="file" accept="application/json,.json" className="hidden" onChange={onImportFile} aria-label="Importar archivo JSON" />
        <div inert={locked} className="mx-auto max-w-[1360px] px-4 pb-20 sm:px-8">
            <TopBar page={page} count={items.length} theme={theme} resolvedTheme={resolvedTheme} onTheme={setTheme} hidden={hidden} onHidden={() => setHidden(v => !v)}
                display={display} onDisplay={setDisplay} onSearch={() => { setInitialLocalSearch(undefined); setAssetSearch('crypto'); }} onAdd={openModal} onExport={exportJSON} onImport={() => fileRef.current?.click()}
                email={account.user.email} syncLabel={syncLabel} onLogout={() => void logout()} leaving={leaving} onMailSettings={() => { setSpaceSubscreen('mail'); setEmailSettings(true); }} onCustomize={() => setPanelEditor(true)} customizing={panelEditor} spaceSubscreen={spaceSubscreen !== null} onPasskey={() => { setSpaceSubscreen('passkey'); void preparePasskeyDialog(); }} passkeyCount={passkeyCount} alerts={alerts} alertStatuses={alertStatuses} onDeleteAlert={id => sync.update(current => ({ ...current, alerts: (current.alerts ?? []).filter(alert => alert.id !== id) }))} onSaveAlert={alert => sync.update(current => ({ ...current, alerts: (current.alerts ?? []).map(item => item.id === alert.id ? { ...alert, id: crypto.randomUUID() } : item) }))} alertHistory={alertHistory} onClearHistory={() => setAlertHistory([])} onAiSettings={() => { setSpaceSubscreen('ai'); setAiSettingsRequest(value => value + 1); }} quietHours={view.portfolio.preferences.quietHours} onQuietHours={value => sync.update(current => ({ ...current, preferences: { ...current.preferences, quietHours: value } }))} alertCount={alerts.length} triggeredCount={triggeredAlerts.length} />
            <div style={page === 'assistant' || view.portfolio.preferences.showQuotesBar === false ? { display: 'none' } : undefined} className="ticker" role="group" aria-label="Cotizaciones de referencia">
                <div className="ticker-track">
                    {[false, true].map(duplicate => <div className="ticker-group" key={String(duplicate)} aria-hidden={duplicate || undefined}>
                        <span title={`Fuente: ${fxSource}`}>USDC <b>{fxRate ? money(fxRate, 'ARS') : '—'}</b></span>
                        {compare.map(k => <span key={k}>{dollarLabels[k]} <b>{money(rates[k].venta, 'ARS')}</b></span>)}
                        <MarketHours />
                        <span role={duplicate ? undefined : 'status'}>{priceError ? 'Cotizaciones parciales' : updated ? `Actualizado ${updated}` : 'Consultando…'}</span>
                        <span><span className={statusDot} aria-hidden="true" style={{ alignSelf: 'center' }} />{syncLabel}</span>
                    </div>)}
                </div>
            </div>
            <main ref={mainRef} inert={false} className={page === 'assistant' ? 'pt-3' : undefined}>
                <header style={page === 'assistant' ? { display: 'none' } : undefined} className="mb-5 mt-8 flex flex-wrap items-end justify-between gap-4">
                    <div><p className="lb mb-2">PANEL PERSONAL / {pageInfo.label.toUpperCase()}</p><h1 ref={titleRef} tabIndex={-1} className="text-[clamp(2.2rem,5vw,3.3rem)] font-light leading-none tracking-[-.045em] outline-none">{pageInfo.title}<span className="sig">.</span></h1><p className="mu mt-3">{pageInfo.description}</p></div>
                </header>
                {view.error && view.status !== 'expired' && <div role="alert" className="mb-4 rounded-xl border border-[var(--neg)]/30 bg-[var(--negbg)] px-4 py-3 text-[12px]"><p>{view.error}</p><div className="mt-3 flex flex-wrap gap-4">{view.status === 'conflict' ? <button onClick={() => void reloadPortfolio()} className="underline">Cargar versión guardada</button> : <button onClick={() => void sync.flush()} className="underline">Reintentar guardado</button>}<button onClick={() => void exportJSON()} className="underline">Exportar mis cambios</button></div></div>}
                {legacy && <div className="card mb-4 p-4 text-[12px]"><p>Encontramos {legacy.investments.length} inversiones guardadas en este navegador. Podés agregarlas a la cuenta de <strong>{account.user.email}</strong>.</p><div className="mt-3 flex gap-4"><button disabled={view.status === 'saving'} onClick={() => void importLegacy()} className="underline disabled:opacity-50">Guardar en mi cuenta</button><button onClick={() => setLegacy(null)} className="text-[var(--muted)]">Ahora no</button></div></div>}
                {notice && <div role="status" className="mb-4 flex items-start justify-between gap-3 rounded-xl border border-[var(--line2)] bg-[var(--raised)] px-4 py-3 text-[12px]"><span>{notice}</span><button onClick={() => setNotice('')} aria-label="Cerrar aviso" className="text-[var(--muted)] hover:text-[var(--ink)]"><HugeiconsIcon icon={Cancel01Icon} size={14} /></button></div>}
                {priceError && <div role="status" className="mb-4 rounded-xl border border-[var(--neg)]/30 bg-[var(--negbg)] px-4 py-3 text-[12px] text-[var(--muted)]">Algunas cotizaciones no están disponibles. Los valores pueden estar incompletos o usar el monto original. <button onClick={() => void refresh()} className="ml-1 text-[var(--ink)] underline">Reintentar</button></div>}
                {!fxRate && items.some(i => i.currency !== display) && <div className="mb-4 rounded-xl border border-[var(--neg)]/30 bg-[var(--negbg)] px-4 py-3 text-[12px]">No se puede convertir toda la cartera a {display} sin la cotización de USDC en pesos. Los totales se muestran como —.</div>}
                {unseenAlerts.length > 0 && page !== 'prices' && <AlertToast key={alertSignature} title={unseenAlerts.length === 1 ? 'Alerta activa' : `${unseenAlerts.length} alertas activas`} message={unseenAlerts.length === 1 ? `${unseenAlerts[0].assetName} · ${alertStatuses[unseenAlerts[0].id].message}` : 'Hay novedades en tus activos.'} onClose={dismissAlerts} onOpen={() => { window.dispatchEvent(new CustomEvent('open-alert-settings')); dismissAlerts(); }} />}
                <MarketChat provider={aiProvider} setProvider={setAiProvider} showButton={view.portfolio.preferences.showChatButton !== false} fullPage={page === 'assistant'} items={items} dirty={view.dirty} settingsRequest={aiSettingsRequest} returnToSpace={spaceSubscreen === 'ai'} onSettingsClose={() => setSpaceSubscreen(null)} onAdd={investment => setItems(prev => [...prev, investment])} onSell={openSale} />
                {page === 'goals' && <Suspense fallback={<p role="status" className="mu p-5">Cargando objetivos…</p>}><Goals provider={aiProvider} setProvider={setAiProvider} onAiSettings={() => setAiSettingsRequest(value => value + 1)} categories={byKind} targets={view.portfolio.preferences.allocationTargets} format={fmt} incompleteQuotes={items.some(item => item.kind !== 'rate' && !!item.coin && prices[`${item.kind}:${item.coin}`] == null)} onSave={targets => sync.update(current => ({ ...current, preferences: { ...current.preferences, allocationTargets: targets } }))} /></Suspense>}
                {page === 'prices' && <Suspense fallback={<p role="status" className="mu p-5">Cargando precios…</p>}><PricesPage items={items} onAddLocal={investment => setItems(prev => [...prev, investment])} onChooseLocal={selectLocalAsset} alerts={alerts} statuses={alertStatuses} onAdd={alert => sync.update(current => ({ ...current, alerts: [...(current.alerts ?? []), alert] }))} /></Suspense>}
                {page === 'imports' && <ImportDocuments portfolio={view.portfolio} update={sync.update} onMailSettings={() => setEmailSettings(true)} mailRevision={emailSettingsRevision} />}
                {page === 'marketCalendar' && <MarketCalendar investments={items} />}
                {page === 'dividends' && <Dividends dirty={view.dirty} hidden={hidden} userId={account.user.id} portfolioKey={dividendFingerprint} items={items} alerts={alerts} onAddAlert={alert => sync.update(current => ({ ...current, alerts: [...(current.alerts ?? []), alert] }))} />}

                {page === 'investments' && <div className="mb-4 flex justify-end"><div className="seg" role="group" aria-label="Vista de inversiones"><button type="button" aria-pressed={investmentView === 'list'} onClick={() => setInvestmentView('list')}>Lista</button><button type="button" aria-pressed={investmentView === 'map'} onClick={() => setInvestmentView('map')}>Mapa 3D</button></div></div>}
                {page === 'investments' && investmentView === 'map' && <Suspense fallback={<div className="card p-8 text-[13px] text-[var(--muted)]" role="status">Cargando mapa…</div>}><PortfolioMap positions={mapPositions} format={fmt} /></Suspense>}
                <div className="flex flex-col">
                    <div style={{ order: panelOrder('value') }} hidden={page !== 'summary' || !visiblePanels.includes('value')}>
                        <section className="mb-3.5 grid gap-3.5 lg:grid-cols-[1.5fr_1fr]" aria-label="Valor de la cartera">
                            <article className="card hero-glow flex min-h-[360px] flex-col overflow-hidden p-6">
                                <div className="flex items-center justify-between"><span className="lb">VALOR ACTUAL</span></div>
                                {items.length > 0 && <fieldset className="mt-4"><legend className="mu mb-2 text-[11px]">Incluir en el resumen</legend><div className="flex flex-wrap gap-2">{kinds.filter(k => k.id !== 'all' && allCount(k.id) > 0).map(k => { const category = k.id as Exclude<Filter, 'all'>; const selected = !hiddenSummaryKinds.includes(category); return <button key={category} type="button" aria-pressed={selected} onClick={() => setHiddenSummaryKinds(prev => prev.includes(category) ? prev.filter(id => id !== category) : [...prev, category])} className={`rounded-full border px-3 py-1.5 text-[11px] transition-colors ${selected ? 'border-[var(--line2)] bg-[var(--raised)] text-[var(--ink)]' : 'border-[var(--line)] text-[var(--muted)] opacity-60'}`}>{k.label}</button>; })}</div></fieldset>}
                                <p className="big mt-6" aria-label={hidden ? 'Monto oculto' : undefined}><AnimatedAmount key={page} value={summaryCurrent} currency={display} hidden={hidden} large /></p>
                                <div className="mt-4 flex flex-wrap items-center gap-3"><span className={`pill ${summaryGain >= 0 ? '' : 'neg'}`}>
                                    <HugeiconsIcon
                                        icon={summaryGain >= 0 ? ChartIncreaseIcon : ChartDecreaseIcon}
                                        size={16}
                                        color={summaryGain >= 0 ? "#22c55e" : "#ef4444"}
                                        strokeWidth={2}
                                    />
                                    {Number.isFinite(summaryGainPct) ? percent(summaryGainPct) : '—'}</span><span className="mu">{Number.isFinite(summaryGain) ? `${fmt(summaryGain)} respecto al capital aportado` : 'Rendimiento no disponible: hay costos desconocidos'}</span></div>
                                {slicesForBar.length > 0 && <div className="mt-7"><div className="dm" role="img" aria-label={`Distribución: ${slicesForBar.map(k => `${k.label} ${(k.value / slicesTotal * 100).toFixed(0)}%`).join(', ')}`}>{slicesForBar.map(k => <i key={k.label} style={{ ['--c' as string]: k.color, flex: k.value }} />)}</div><div className="lg mt-3">{slicesForBar.map(k => <span key={k.label} style={{ ['--c' as string]: k.color }}>{k.label} {(k.value / slicesTotal * 100).toFixed(0)}%</span>)}</div></div>}
                                {summaryChart && <svg className="chart-animate line-chart mt-auto -mx-6 -mb-6 block h-[100px] w-[calc(100%+3rem)] pt-4" viewBox={`0 0 ${summaryChart.w} ${summaryChart.h}`} preserveAspectRatio="none" aria-hidden="true"><defs><linearGradient id="hero-fill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" style={{ stopColor: 'var(--sig)', stopOpacity: .28 }} /><stop offset="100%" style={{ stopColor: 'var(--sig)', stopOpacity: 0 }} /></linearGradient></defs><path d={summaryChart.area} fill="url(#hero-fill)" /><path d={summaryChart.line} fill="none" style={{ stroke: 'var(--sig)' }} strokeWidth="2" vectorEffect="non-scaling-stroke" strokeLinejoin="round" /></svg>}
                            </article>
                            <div className="grid gap-3.5">
                                <article className="card p-6">
                                    <p className="lb">CAPITAL Y RESULTADO</p>
                                    <div className="mt-4 grid grid-cols-2 gap-4"><div><p className="mu">Aportado</p><p className="mt-1 break-all text-[clamp(1.2rem,2.4vw,1.8rem)] font-light tabular-nums tracking-tight"><AnimatedAmount key={page} value={summaryInvested} currency={display} hidden={hidden} /></p></div><div><p className="mu">Resultado</p><p className="mt-1 break-all text-[clamp(1.2rem,2.4vw,1.8rem)] font-light tabular-nums tracking-tight" style={{ color: summaryGain >= 0 ? 'var(--sig)' : 'var(--neg)' }}><AnimatedAmount key={page} value={summaryGain} currency={display} hidden={hidden} /></p></div></div>
                                    {Number.isFinite(summaryGain) && <><div className="trk mt-5" role="img" aria-label={`Capital ${(capShare * 100).toFixed(0)}% del valor actual`}><i style={{ width: `${Math.min(100, capShare * 100)}%` }} /><b style={{ width: `${Math.max(0, 100 - capShare * 100)}%`, background: summaryGain >= 0 ? 'var(--sig)' : 'var(--neg)' }} /></div>
                                    <div className="mu mt-2 flex justify-between text-[11px]"><span>capital</span><span style={{ color: summaryGain >= 0 ? 'var(--sig)' : 'var(--neg)' }}>{summaryGain >= 0 ? 'ganancia' : 'pérdida'}</span></div></>}
                                </article>
                                <article className="card side-glow p-6">
                                    <div className="flex items-center justify-between"><p className="lb">REFERENCIA USDC</p><RefreshButton onClick={() => void refresh()} loading={refreshing} label="Actualizar cotizaciones" /></div>
                                    <p className="mt-3 text-[clamp(1.6rem,3vw,2.2rem)] font-light leading-none tracking-tight tabular-nums">{fxRate ? money(fxRate, 'ARS') : 'No disponible'}</p>
                                    <p className="mu mt-2 flex items-center gap-1 text-[11px]">
                                        1 USDC en pesos · convierte USD
                                        <HugeiconsIcon
                                            icon={ArrowReloadHorizontalIcon}
                                            size={13}
                                            className="inline-block"
                                        />
                                        ARS en toda la app
                                    </p>
                                    {compare.length > 0 && <div className="mt-4 divide-y divide-[var(--line)] border-t border-[var(--line)]">{compare.map(k => { const gap = fxRate ? (fxRate / rates[k].venta - 1) * 100 : NaN; return <div key={k} className="flex items-center justify-between py-2 font-mono text-[12px]"><span className="text-[var(--muted)]">{dollarLabels[k]}</span><span className="tabular-nums">{money(rates[k].venta, 'ARS')}</span><span className={`pill ${gap >= 0 || !Number.isFinite(gap) ? '' : 'neg'}`} title={`USDC ${Number.isFinite(gap) ? percent(gap) : '—'} respecto al dólar ${dollarLabels[k]}`}>{Number.isFinite(gap) ? percent(gap) : '—'}</span></div>; })}</div>}
                                    <div className="mt-3 space-y-1"><p className="mu text-[10.5px]">Precio de USDC: <a href="https://www.coingecko.com/en/coins/usd-coin" target="_blank" rel="noopener noreferrer" className="underline underline-offset-2 hover:text-[var(--ink)]">{usdc ? fxSource : 'CoinGecko'}</a></p><QuoteSource source="dollar" label="Dólares comparados" /></div>
                                </article>
                            </div>
                        </section>
                    </div>

                    <div style={{ order: panelOrder('macro') }} hidden={page !== 'summary' || !visiblePanels.includes('macro')}>{page === 'summary' && visiblePanels.includes('macro') && <MacroDashboard rates={rates} refreshDollars={() => void refresh()} dollarLoading={refreshing} />}</div>

                    <div style={{ order: panelOrder('streak') }} hidden={page !== 'summary' || !visiblePanels.includes('streak')}><ContributionStreak items={items.filter(item => !item.costUnknown)} hidden={hidden} /></div>

                    <div style={{ order: panelOrder('evolution') }} hidden={page !== 'evolution' && (page !== 'summary' || !visiblePanels.includes('evolution'))}>
                        <section className="card mb-3.5 p-5 sm:p-6"><div className="flex flex-wrap items-start justify-between gap-3"><div><p className="lb">EVOLUCIÓN</p><p className="mu mt-2 text-[11.5px]">Estimada · no es un historial real de precios</p></div><div role="group" aria-label="Período de evolución" className="seg">{([['7d', '7D'], ['1m', '1M'], ['6m', '6M'], ['1a', '1A'], ['todo', 'Todo']] as const).map(([id, text]) => <button key={id} type="button" onClick={() => setRange(id)} aria-pressed={range === id}>{text}</button>)}</div></div>
                            {chart ? <><div className="relative mt-7 touch-pan-y" role="slider" tabIndex={0} aria-label="Explorar evolución estimada con las flechas" aria-valuemin={0} aria-valuemax={chart.points.length - 1} aria-valuenow={chartIndex ?? chart.points.length - 1} aria-valuetext={chartPoint ? `${chartDate(chartPoint.t)}: ${fmt(chartPoint.value)}` : `Hoy: ${fmt(current)}`} onBlur={() => setChartIndex(null)} onKeyDown={event => { if (event.key === 'ArrowLeft' || event.key === 'ArrowRight') { event.preventDefault(); setChartIndex(index => Math.max(0, Math.min(chart.points.length - 1, (index ?? chart.points.length - 1) + (event.key === 'ArrowRight' ? 1 : -1)))); } }} onPointerDown={event => { const rect = event.currentTarget.getBoundingClientRect(); const x = (event.clientX - rect.left) / rect.width * chart.w; setChartIndex(Math.max(0, Math.min(chart.points.length - 1, Math.round((x - 12) / (chart.w - 24) * (chart.points.length - 1))))); }} onPointerMove={event => { const rect = event.currentTarget.getBoundingClientRect(); const x = (event.clientX - rect.left) / rect.width * chart.w; setChartIndex(Math.max(0, Math.min(chart.points.length - 1, Math.round((x - 12) / (chart.w - 24) * (chart.points.length - 1))))); }} onPointerLeave={event => { if (event.pointerType === 'mouse') setChartIndex(null); }}>
                                <svg viewBox={`0 0 ${chart.w} ${chart.h}`} preserveAspectRatio="none" className="chart-animate line-chart h-[230px] w-full overflow-visible" aria-hidden="true"><defs><linearGradient id="invest-fill" x1="0" y1="0" x2="0" y2="1"><stop offset="0%" style={{ stopColor: 'var(--sig)', stopOpacity: .24 }} /><stop offset="100%" style={{ stopColor: 'var(--sig)', stopOpacity: 0 }} /></linearGradient></defs>{[.25, .5, .75, 1].map(n => <line key={n} x1="12" x2={chart.w - 12} y1={chart.h * n - 5} y2={chart.h * n - 5} stroke="var(--line2)" strokeDasharray="4 6" />)}{page !== 'evolution' && <path d={chart.area} fill="url(#invest-fill)" />}<path d={chart.line} fill="none" style={{ stroke: 'var(--sig)' }} strokeWidth="2.5" vectorEffect="non-scaling-stroke" strokeLinecap="round" strokeLinejoin="round" />{chartPoint ? <><line x1={chartPoint.x} x2={chartPoint.x} y1="4" y2={chart.h - 12} stroke="var(--muted)" strokeOpacity=".7" strokeDasharray="4 5" /><circle cx={chartPoint.x} cy={chartPoint.y} r="5" style={{ fill: 'var(--sig)' }} stroke="var(--surface)" strokeWidth="3" /></> : <circle cx={chart.nowX} cy={chart.nowY} r="5" style={{ fill: 'var(--sig)' }} stroke="var(--surface)" strokeWidth="3" />}</svg>
                                {chartPoint && <div className="pointer-events-none absolute top-2 z-10 rounded-lg border border-[var(--line2)] bg-[var(--raised)] px-3 py-2 shadow-lg" style={{ left: `${Math.max(2, Math.min(98, chartPoint.x / chart.w * 100))}%`, transform: chartPoint.x > chart.w / 2 ? 'translateX(-100%)' : 'none' }}><p className="mu whitespace-nowrap text-[10px]">{chartDate(chartPoint.t)}</p><p className="mt-1 whitespace-nowrap font-mono text-[12px]">{fmt(chartPoint.value)}</p><p className="mu mt-0.5 text-[10px]">Estimado</p></div>}
                            </div><div className="mu mt-2 flex justify-between text-[11px]"><span>{chart.first}</span><span>Hoy</span></div></> : <div className="grid h-[240px] place-items-center text-center text-[13px] text-[var(--muted)]">{items.length ? 'Sin conversión de moneda disponible.' : 'Agregá tu primera inversión para visualizar la evolución.'}</div>}
                            <p className="mu mt-5 border-t border-[var(--line)] pt-4 text-[10.5px] leading-5">Los valores anteriores de CEDEARs y cripto se interpolan entre la compra y el precio actual. La conversión usa el USDC actual; no refleja rendimientos históricos reales.</p>
                        </section>
                        {page === 'evolution' && <Benchmarks composition={byKind} compositionIncomplete={items.some(item => item.kind !== 'rate' && !!item.coin && prices[`${item.kind}:${item.coin}`] == null)} start={benchmarkStart} end={today} months={effectiveMonths} onMonthsChange={setBenchmarkMonths} availablePeriods={availablePeriods} valueAt={benchmarkValue} priceAt={benchmarkUnitPrice} available={(temporarySelected || benchmarkItems.length > 0) && benchmarkHistory !== null && !benchmarkHistoryError && (Boolean(fxRate) || (temporarySelected ? ['cedear', 'arg-stock', 'bond', 'fund'].includes(temporaryBenchmark.kind) : benchmarkItems.every(i => i.currency === 'ARS' && i.kind !== 'crypto')))} historyLoading={benchmarkHistory === null && !benchmarkHistoryError} historyError={benchmarkHistoryError} actualReturnArs={actualReturnArs} selection={selectedBenchmark?.value ?? 'all'} onSelectionChange={setBenchmarkSelection} options={temporaryBenchmark ? [...benchmarkOptions, { value: 'temporary', label: `${temporaryBenchmark.name} · temporal` }] : benchmarkOptions} onSearch={() => { benchmarkSearchRequest.current++; setBenchmarkSearchStatus(''); setBenchmarkSearchOpen(true); }} searchStatus={benchmarkSearchStatus} selectionLabel={selectedBenchmark?.label ?? 'Mi cartera'} averageMonthlyReturn={averageMonthlyReturn} />}
                    </div>

                    {page === 'inflation' && <Inflation />}
                    <div style={{ order: panelOrder('distribution') }} hidden={page !== 'summary' || !visiblePanels.includes('distribution')}>{items.length > 0 && <Distribution byKind={byKind} byCurrency={byCurrency} byAsset={byAsset} bySector={bySector} byCountry={byCountry} format={fmt} />}</div>

                    <div style={{ order: panelOrder('investments') }} hidden={(page !== 'investments' || investmentView !== 'list') && (page !== 'summary' || !visiblePanels.includes('investments'))}>
                        <section className="card overflow-hidden" aria-label="Mis inversiones">
                            <div className="flex flex-wrap items-center justify-between gap-3 px-5 pt-5 sm:px-6"><div><p className="lb">MIS INVERSIONES <span className="ml-2 text-[var(--faint)]">{filtered.length}</span></p><p className="mu mt-2 text-[11.5px]">Tocá una inversión para ver sus detalles · ⋯ para más opciones</p></div>
                                <div className="flex items-center gap-2"><label className="relative hidden sm:block"><HugeiconsIcon icon={Search01Icon} size={15} className="absolute left-3 top-1/2 -translate-y-1/2 text-[var(--faint)]" /><input aria-label="Buscar en mis inversiones" value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar en mi cartera…" className="w-52 rounded-[10px] border border-[var(--line)] bg-[var(--raised)] py-2 pl-9 pr-3 text-[12px] outline-none focus:border-[var(--muted)]" /></label><RefreshButton onClick={() => void refresh()} loading={refreshing} label="Actualizar precios" /></div></div>
                            <div className="tabs px-4 pb-1 pt-4 sm:px-5" role="group" aria-label="Filtrar por tipo">{kinds.map(k => <button key={k.id} type="button" aria-pressed={filter === k.id} onClick={() => setFilter(k.id)}>{k.id !== 'all' && <span className="mr-2 inline-block h-1.5 w-1.5 rounded-full align-middle" style={{ background: k.color }} />}{k.id === 'all' ? 'Todas' : k.label}<em>{allCount(k.id)}</em></button>)}</div>
                            <div className="px-5 pt-3 sm:hidden"><input aria-label="Buscar en mis inversiones" value={search} onChange={e => setSearch(e.target.value)} placeholder="Buscar en mi cartera…" className={field} /></div>
                            <div className="mt-3">{filtered.length ? filtered.map(i => {
                                const v = valueAt(i, today, prices, today, officialRate); const change = i.amount > 0 ? (v - i.amount) / i.amount * 100 : 0; const missing = i.kind !== 'rate' && (i.coin && prices[`${i.kind}:${i.coin}`] == null); const cat = categoryOf(i); const sub = isLocal(i) ? `${titleFor(i.kind)} · ${i.coin?.split('~')[0]}` : i.kind === 'rate' ? `Con tasa · ${i.rate}% ${i.period === 'year' ? 'anual' : 'mensual'}` : cat === 'index' ? `Índice · ${indexName(i.coin ?? '')}` : i.kind === 'cedear' ? `CEDEAR · ${i.coin}` : i.kind === 'stock' ? `Acción · ${i.coin}` : `Cripto · ${i.coin}`;
                                return <div key={i.id} className={`li cursor-pointer ${ctx?.id === i.id ? 'menu-open' : ''}`} onClick={e => { if ((e.target as HTMLElement).closest('button, a')) return; detailOpenerRef.current = e.currentTarget.querySelector('button[data-detail]'); setDetailId(i.id); }} onContextMenu={e => { e.preventDefault(); setCtx({ x: e.clientX, y: e.clientY, id: i.id }); }}>
                                    <div className="tk" style={{ ['--c' as string]: colorOf(cat) }} aria-hidden="true">{tickerOf(i)}</div>
                                    <div className="min-w-0"><button type="button" data-detail onClick={e => { detailOpenerRef.current = e.currentTarget; setDetailId(i.id); }} className="block max-w-full truncate text-left text-[14px] font-medium hover:underline focus-visible:outline-2 focus-visible:outline-offset-2" aria-label={`Ver detalle de ${i.name}`}>{i.name}</button><p className="mu mt-1 text-[11.5px]">{sub} <span>· {i.costUnknown ? 'Importado ' : ''}{formatDate(i.date)}</span></p>{missing && <p className="mu mt-0.5 text-[10px]">{i.costUnknown ? 'Sin precio disponible' : 'Sin precio · se muestra el monto original'}</p>}</div>
                                    <div className="r hid"><p><span className="amount-transition">{i.costUnknown ? '—' : mny(i.amount, i.currency)}</span></p><p className="mu mt-1 text-[10px]">{i.costUnknown ? 'Costo desconocido' : 'Invertido'}</p></div>
                                    <div className="r hid"><p><span key={mny(v, i.currency)} className="amount-transition">{mny(v, i.currency)}</span></p><div className="mt-1 text-[10px] text-[var(--muted)]">{i.kind === 'rate' ? <span title="Valor calculado con el monto, la fecha y la tasa que ingresaste">Tasa ingresada por vos</span> : <QuoteSource source={i.kind === 'fund' ? 'fund' : i.kind === 'arg-stock' || i.kind === 'bond' ? 'local' : i.kind} asset={i.coin} label={missing ? 'Proveedor' : 'Fuente'} className="justify-end" />}</div></div>
                                    <div className="r"><span className={`pill ${change >= 0 ? '' : 'neg'}`}>{missing || i.costUnknown ? '—' : percent(change)}</span></div>
                                    <button type="button" onClick={e => { const r = e.currentTarget.getBoundingClientRect(); setCtx(ctx?.id === i.id ? null : { x: r.right - 220, y: r.bottom + 6, id: i.id }); }} aria-haspopup="menu" aria-expanded={ctx?.id === i.id} aria-label={`Acciones de ${i.name}`} className="ibtn !h-9 !w-9 !border-transparent !bg-transparent"><HugeiconsIcon icon={MoreHorizontalIcon} size={17} /></button>
                                </div>;
                            }) : <div className="flex flex-col items-center px-4 py-16 text-center"><div className="mb-4 grid h-12 w-12 place-items-center rounded-2xl bg-[var(--raised)]"><HugeiconsIcon icon={CoinsBitcoinIcon} size={21} className="text-[var(--muted)]" /></div><h3 className="text-[14px] font-medium">{items.length ? 'No hay inversiones con este filtro' : 'Tu cartera está vacía'}</h3><p className="mt-2 max-w-xs text-[12px] text-[var(--muted)]">{items.length ? 'Probá otra categoría o búsqueda.' : 'Empezá cargando una inversión o importá un archivo exportado.'}</p>{!items.length && <div className="mt-5 flex gap-2"><button onClick={openModal} className="btn-primary !min-h-10 !text-[13px]">Agregar inversión</button><button onClick={() => fileRef.current?.click()} className="btn-ghost">Importar datos</button></div>}</div>}</div>
                        </section>
                    </div>
                </div>
                {page === 'investments' && investmentView === 'list' && <AssetPerformance items={items} hidden={hidden} />}
                {page === 'investments' && investmentView === 'list' && (view.portfolio.sales?.length ?? 0) > 0 && <section className="card mt-4 p-5"><p className="lb">VENTAS REGISTRADAS</p><div className="mt-3 divide-y divide-[var(--line)]">{[...(view.portfolio.sales ?? [])].reverse().map(sale => <div key={sale.id} className="flex flex-wrap justify-between gap-2 py-3 text-[12px]"><span>{sale.name} · {formatDate(sale.date)} · {(sale.fraction * 100).toFixed(2)}%</span><span>Neto {mny(sale.proceeds, sale.currency)} · costo {mny(sale.cost, sale.costCurrency)}{sale.fee != null ? ` · comisión ${mny(sale.fee, sale.currency)}` : ''}{sale.executionPrice != null ? ` · precio ${mny(sale.executionPrice, sale.currency)} por unidad` : ''}{sale.currency === sale.costCurrency ? ` · resultado ${mny(sale.proceeds - sale.cost, sale.currency)}` : ''}</span></div>)}</div></section>}
                <footer className="mu mt-8 space-y-2 text-[10px]">
                    <div className="flex flex-wrap items-center gap-x-4 gap-y-1" aria-label="Fuentes de las cotizaciones"><QuoteSource source="usdc" label="USDC" /><QuoteSource source="dollar" label="Dólares" /><QuoteSource source="crypto" label="Cripto" /><QuoteSource source="cedear" label="CEDEARs e índices" /></div>
                    <nav aria-label="Información legal" className="flex flex-wrap gap-2 pt-2"><a href="/politicas" className="rounded-lg border border-[var(--line2)] px-3 py-2 text-[11px] hover:bg-[var(--raised)] focus-visible:outline-2 focus-visible:outline-offset-2">Política de privacidad</a><a href="/condiciones" className="rounded-lg border border-[var(--line2)] px-3 py-2 text-[11px] hover:bg-[var(--raised)] focus-visible:outline-2 focus-visible:outline-offset-2">Términos y condiciones</a></nav>
                </footer>
            </main>
        </div>
        {detailItem && (() => {
            const item = detailItem;
            const quoted = item.kind === 'rate' || !item.coin ? undefined : prices[`${item.kind}:${item.coin}`];
            const quoteCurrency: Currency = item.kind === 'cedear' || isLocal(item) ? 'ARS' : 'USD';
            const available = item.kind === 'rate' || (quoted != null && Number.isFinite(quoted) && quoted > 0 && item.units != null && (quoteCurrency === item.currency || !!fxRate));
            const currentValue = available ? valueAt(item, today, prices, today, officialRate) : NaN;
            const result = currentValue - item.amount;
            const unitPrice = (price: number | undefined, currency: Currency) => hidden ? MASK : price != null && Number.isFinite(price) ? new Intl.NumberFormat('es-AR', { style: 'currency', currency, maximumSignificantDigits: 10 }).format(price) : 'No disponible';
            const units = item.units == null ? 'No disponible' : hidden ? MASK : new Intl.NumberFormat('es-AR', { maximumSignificantDigits: 10 }).format(item.units);
            return <div className="fixed inset-0 z-50 flex items-end justify-center bg-black/65 p-0 backdrop-blur-[5px] sm:items-center sm:p-4" onMouseDown={event => { if (event.target === event.currentTarget) setDetailId(null); }}>
                <section role="dialog" aria-modal="true" aria-labelledby="investment-detail-title" className="max-h-[90dvh] w-full overflow-y-auto rounded-t-[22px] border border-[var(--line2)] bg-[var(--surface)] p-5 shadow-2xl sm:max-w-[500px] sm:rounded-[22px] sm:p-6">
                    <div className="flex items-start justify-between gap-4"><div><p className="lb">DETALLE DE INVERSIÓN</p><h2 id="investment-detail-title" className="mt-2 break-words text-[24px] font-light tracking-tight">{item.name}</h2><p className="mu mt-1 text-[12px]">{categoryOf(item) === 'index' ? 'Índice' : titleFor(item.kind)}{item.coin ? ` · ${item.coin}` : ''}</p></div><button ref={detailCloseRef} type="button" onClick={() => setDetailId(null)} aria-label="Cerrar detalle" className="rounded-lg p-1.5 text-[var(--muted)] hover:text-[var(--ink)]"><HugeiconsIcon icon={Cancel01Icon} size={19} /></button></div>
                    <div className="mt-6 rounded-xl border border-[var(--line)] bg-[var(--raised)] p-4"><p className="mu text-[11px]">Valor actual de la posición</p><p className="mt-1 break-all text-[27px] font-light tabular-nums">{available ? mny(currentValue, item.currency) : 'No disponible'}</p><p className="mt-2 text-[12px]" style={{ color: available && !item.costUnknown ? result >= 0 ? 'var(--sig)' : 'var(--neg)' : 'var(--muted)' }}>{item.costUnknown ? 'Rendimiento no disponible: costo de compra desconocido' : available ? `${mny(result, item.currency)} · ${percent(item.amount > 0 ? result / item.amount * 100 : 0)}` : 'No hay cotización o conversión disponible'}</p></div>
                    <dl className="mt-5 grid grid-cols-2 gap-x-4 gap-y-5 text-[13px]"><div><dt className="mu text-[11px]">{item.costUnknown ? 'Fecha de importación' : 'Fecha registrada'}</dt><dd className="mt-1">{formatDate(item.date)}</dd></div><div><dt className="mu text-[11px]">{item.costUnknown ? 'Costo de compra' : 'Monto registrado'}</dt><dd className="mt-1 break-all tabular-nums">{item.costUnknown ? 'Desconocido' : mny(item.amount, item.currency)}</dd></div>{item.kind !== 'rate' ? <><div><dt className="mu text-[11px]">Unidades actuales</dt><dd className="mt-1 break-all tabular-nums">{units}</dd></div><div><dt className="mu text-[11px]">Precio de compra por unidad</dt><dd className="mt-1 break-all tabular-nums">{unitPrice(item.purchasePrice, quoteCurrency)}</dd></div><div><dt className="mu text-[11px]">Precio actual por unidad</dt><dd className="mt-1 break-all tabular-nums">{unitPrice(quoted, quoteCurrency)}</dd></div></> : <div><dt className="mu text-[11px]">Tasa ingresada</dt><dd className="mt-1">{item.rate}% {item.period === 'month' ? 'mensual' : 'anual'}</dd></div>}</dl>
                    {item.kind === 'rate' && item.maturityDate && <p className="mu mt-4 text-[12px]">Vencimiento: {formatDate(item.maturityDate)} · cobro estimado {mny(valueAt(item, dateMillis(item.maturityDate), prices, today, officialRate), item.currency)} (capital e interés).</p>}
                    {item.kind !== 'rate' && item.purchasePrice == null && <p className="mu mt-5 text-[11px] leading-5">{item.costUnknown ? 'Podés editar la inversión para registrar su costo de compra.' : 'No se guardó un precio de compra para esta posición. El monto registrado puede ser un valor actual ingresado al cargarla.'}</p>}
                    <p className="mu mt-3 text-[11px] leading-5">Las unidades y el monto corresponden a la posición que conservás; pueden haber cambiado si registraste ventas.</p>
                    {!isLocal(item) && <button type="button" onClick={() => { setDetailId(null); openEdit(item); }} className="btn-ghost mt-5 w-full">Editar inversión</button>}
                </section>
            </div>;
        })()}
        {ctx && ctxItem && <ContextMenu x={ctx.x} y={ctx.y} title={ctxItem.name} items={menuFor(ctxItem)} onClose={closeCtx} />}
        {passkeyDialog && <div className="settings-subscreen settings-subscreen-narrow fixed inset-0 z-[80] flex items-center justify-center bg-black/70 p-4" onMouseDown={event => { if (event.target === event.currentTarget && !passkeyBusy) { setPasskeyDialog(false); setSpaceSubscreen(null); } }}>
            <section role="dialog" aria-modal="true" aria-labelledby="passkey-title" className="card w-full max-w-md p-6 shadow-2xl">
                {spaceSubscreen === 'passkey' && <button type="button" className="btn-ghost mb-6" disabled={passkeyBusy} onClick={() => { setPasskeyDialog(false); setSpaceSubscreen(null); }}><span aria-hidden="true"><HugeiconsIcon icon={ChevronLeft} size={20} /></span> </button>}<h2 id="passkey-title" className="text-xl font-light">Passkeys y llaves de seguridad</h2>
                <p className="mu mt-3 text-[13px] leading-6">{passkeyCount === null ? 'No se pudo consultar el estado de tus passkeys.' : passkeyCount ? `Tenés ${passkeyCount} ${passkeyCount === 1 ? 'passkey registrada' : 'passkeys registradas'} en tu cuenta.` : 'Todavía no tenés passkeys registradas.'}</p>
                <p className="mu mt-2 text-[12px] leading-5">Podés agregar una passkey para ingresar con Face ID, otro dispositivo o una llave de seguridad.</p>
                {savedPasskeys.length > 0 && <div className="mt-4 space-y-2">{savedPasskeys.map((key, index) => <div key={key.id} className="flex items-center justify-between gap-3 rounded-xl border border-[var(--line)] p-3"><div><p className="text-[12px] font-medium">Passkey {index + 1}</p><p className="mu mt-1 text-[11px]">{key.createdAt ? `Agregada el ${new Date(key.createdAt).toLocaleDateString('es-AR')}` : 'Fecha de registro no disponible'}{key.lastUsedAt ? ` · Último uso: ${new Date(key.lastUsedAt).toLocaleDateString('es-AR')}` : ''}</p></div><button type="button" className="text-[12px] text-[var(--neg)] underline" disabled={passkeyBusy} aria-label={`Eliminar passkey ${index + 1}`} onClick={() => { if (!window.confirm('¿Eliminar esta passkey de tu cuenta?')) return; setPasskeyBusy(true); setPasskeyMessage(''); void removePasskey(key.id).then(() => { setSavedPasskeys(current => current.filter(item => item.id !== key.id)); setPasskeyCount(count => count === null ? null : Math.max(0, count - 1)); setPasskeyMessage('Passkey eliminada de tu cuenta. También podés quitarla del administrador de contraseñas de tu dispositivo.'); }).catch(error => setPasskeyMessage(error instanceof Error ? error.message : 'No se pudo eliminar la passkey.')).finally(() => setPasskeyBusy(false)); }}>Eliminar</button></div>)}</div>}
                {passkeyMessage && <p role="status" className="mt-4 rounded-xl border border-[var(--line)] bg-[var(--raised)] p-3 text-[12px]">{passkeyMessage}</p>}
                <div className="mt-5 flex flex-wrap justify-end gap-2"><button type="button" className="btn-ghost" disabled={passkeyBusy} onClick={() => { setPasskeyDialog(false); setSpaceSubscreen(null); }}>{spaceSubscreen === 'passkey' ? 'Volver' : 'Cerrar'}</button>{passkeyOptions ? <button type="button" className="btn-primary" disabled={passkeyBusy} onClick={() => void enablePasskey()}>{passkeyBusy ? 'Activando…' : 'Crear passkey'}</button> : <button type="button" className="btn-primary" disabled={passkeyBusy} onClick={() => void preparePasskeyDialog()}>{passkeyBusy ? 'Preparando…' : 'Agregar passkey'}</button>}</div>
            </section>
        </div>}
        {panelEditor && <PanelEditor selected={visiblePanels} showChatButton={view.portfolio.preferences.showChatButton !== false} showQuotesBar={view.portfolio.preferences.showQuotesBar !== false} onClose={closePanelEditor} onSave={(next, options) => { sync.update(current => ({ ...current, preferences: { ...current.preferences, panels: [...next, 'panel-v2'], ...options } })); setPanelEditor(false); }} />}
        {sellItem && <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/65 p-4" onMouseDown={e => { if (e.target === e.currentTarget) setSellId(null); }}>
            <section role="dialog" aria-modal="true" aria-label="Registrar venta" className="card max-h-[90dvh] w-full max-w-md overflow-y-auto p-6">
                <h2 className="text-xl">Registrar venta</h2>
                <p className="mu mt-2">{sellItem.name}{sellItem.units != null ? ` · ${hidden ? MASK : new Intl.NumberFormat('es-AR', { maximumSignificantDigits: 10 }).format(sellItem.units)} unidades disponibles` : ''}</p>
                <div className="mt-5"><span className={label}>Moneda de la venta</span><Select<Currency> label="Moneda de la venta" value={sellCurrency} onChange={value => { setSellCurrency(value); setSellExecutionPrice(''); setSellInputAmount(''); setSellFee('0'); setSellError(''); }} options={[{ value: 'ARS', label: 'Pesos argentinos (ARS)' }, { value: 'USD', label: 'Dólares (USD)' }]} /></div>
                <label className={`${label} mt-4`}>{sellItem.kind === 'rate' ? `Valor bruto total de la posición (${sellCurrency})` : `Precio ejecutado por unidad (${sellCurrency})`}<input className={`${field} mt-1`} type="number" inputMode="decimal" min="0" step="any" value={sellExecutionPrice} onChange={e => { setSellExecutionPrice(e.target.value); setSellError(''); }} /></label>
                <div className="mt-4"><p className={label}>Ingresar venta por</p><div className="seg" role="group" aria-label="Forma de ingresar la venta"><button type="button" aria-pressed={sellInputMode === 'percent'} onClick={() => { setSellInputMode('percent'); setSellError(''); }}>Porcentaje</button><button type="button" aria-pressed={sellInputMode === 'amount'} onClick={() => { setSellInputMode('amount'); setSellError(''); }}>Importe bruto</button></div></div>
                {sellInputMode === 'percent' ? <label className={`${label} mt-4`}>Porcentaje a vender<input className={`${field} mt-1`} type="number" inputMode="decimal" min="0" max="100" step="any" value={sellPercent} onChange={e => setSellPercent(e.target.value)} /></label> : <label className={`${label} mt-4`}>Importe bruto a vender ({sellCurrency})<input className={`${field} mt-1`} type="number" inputMode="decimal" min="0" step="any" value={sellInputAmount} onChange={e => setSellInputAmount(e.target.value)} /><span className="mt-2 flex flex-wrap items-center justify-between gap-2">Valor bruto disponible: {Number.isFinite(sellTotal) ? mny(sellTotal, sellCurrency) : 'No disponible'}<button type="button" className="underline" disabled={!Number.isFinite(sellTotal)} onClick={() => setSellInputAmount(String(sellTotal))}>Vender todo</button></span></label>}
                <label className={`${label} mt-4`}>Comisiones y gastos ({sellCurrency})<input className={`${field} mt-1`} type="number" inputMode="decimal" min="0" step="any" value={sellFee} onChange={e => setSellFee(e.target.value)} /></label>
                <div className="mt-4 space-y-1 rounded-xl border border-[var(--line)] bg-[var(--raised)] p-4 text-[12px]"><p>Importe bruto: {Number.isFinite(sellGross) && sellGross > 0 ? mny(sellGross, sellCurrency) : '—'}</p><p>Importe neto: {Number.isFinite(sellNet) && sellNet > 0 ? mny(sellNet, sellCurrency) : '—'}</p>{sellItem.units != null && Number.isFinite(sellFraction) && sellFraction > 0 && sellFraction <= 1 && <p className="mu">Unidades vendidas: {hidden ? MASK : new Intl.NumberFormat('es-AR', { maximumSignificantDigits: 10 }).format(sellItem.units * sellFraction)}</p>}</div>
                <p className="mu mt-3 text-[11px]">El valor inicial puede usar la última cotización disponible: reemplazalo por el de tu comprobante. La comisión se descuenta del importe bruto. Esta acción no ejecuta una orden en tu bróker.</p>{sellError && <p role="alert" className="mt-3 text-[var(--neg)]">{sellError}</p>}
                <div className="mt-5 flex gap-3"><button className="btn-primary" onClick={registerSale}>Registrar venta</button><button className="btn-ghost" onClick={() => setSellId(null)}>Cancelar</button></div>
            </section>
        </div>}
        {modal && <div inert={!!assetSearch} className="fixed inset-0 z-50 flex items-end justify-center bg-black/65 p-0 backdrop-blur-[5px] sm:items-center sm:p-4" onMouseDown={e => { if (e.target === e.currentTarget) closeModal() }}>
            <div role="dialog" aria-modal="true" aria-labelledby="modal-title" className="max-h-[94dvh] w-full overflow-y-auto rounded-t-[22px] border border-[var(--line2)] bg-[var(--surface)] p-5 shadow-[0_25px_90px_rgba(0,0,0,.5)] sm:max-w-[470px] sm:rounded-[22px] sm:p-6">
                <div className="mb-5 flex items-start justify-between"><div><h2 id="modal-title" className="text-[24px] font-light tracking-tight">{editingId ? 'Editar inversión' : 'Nueva inversión'}</h2><p className="mt-1 font-mono text-[11px] text-[var(--muted)]">{editingId ? 'Modificá los datos de esta posición' : 'Registrá una posición en tu cartera'}</p></div><button onClick={closeModal} aria-label="Cerrar" className="rounded-lg p-1.5 text-[var(--muted)] hover:text-[var(--ink)]"><HugeiconsIcon icon={Cancel01Icon} size={19} /></button></div>
                {!editingId && <button type="button" onClick={() => { closeModal(); goTo('/importaciones'); }} className="mb-5 flex w-full items-center gap-3 rounded-xl border border-[var(--line2)] bg-[var(--raised)] px-4 py-3 text-left text-[13px] hover:border-[var(--muted)]"><HugeiconsIcon icon={Upload01Icon} size={19} /><span><span className="block font-medium">Importar PDF o imagen</span><span className="mu mt-1 block text-[11px]">Leer un comprobante y revisar sus operaciones</span></span></button>}
                <form onSubmit={add} className="space-y-4">
                    <div className="grid grid-cols-2 gap-2 sm:grid-cols-3">{(['rate', 'cedear', 'stock', 'crypto'] as const).map(k => <button type="button" key={k} onClick={() => pickKind(k)} aria-pressed={kind === k} className={`flex items-center justify-center gap-2 rounded-[10px] border px-2 py-2.5 text-[12px] ${(kind === k || (k === 'stock' && kind === 'arg-stock')) ? 'border-[var(--line2)] bg-[var(--raised)]' : 'border-[var(--line)] text-[var(--muted)]'}`}><span className="h-1.5 w-1.5 rounded-full" style={{ background: colorOf(k) }} />{k === 'stock' ? 'Acciones' : titleFor(k)}</button>)}<button type="button" aria-pressed={kind === 'fund'} onClick={() => openLocalSearch('funds')} className={`flex items-center justify-center gap-2 rounded-[10px] border px-2 py-2.5 text-[12px] ${kind === 'fund' ? 'border-[var(--line2)] bg-[var(--raised)]' : 'border-[var(--line)] text-[var(--muted)]'}`}><span className="h-1.5 w-1.5 rounded-full" style={{ background: colorOf('fund') }} />FCI</button><button type="button" aria-pressed={kind === 'bond'} onClick={() => openLocalSearch('bonds')} className={`flex items-center justify-center gap-2 rounded-[10px] border px-2 py-2.5 text-[12px] ${kind === 'bond' ? 'border-[var(--line2)] bg-[var(--raised)]' : 'border-[var(--line)] text-[var(--muted)]'}`}><span className="h-1.5 w-1.5 rounded-full" style={{ background: colorOf('bond') }} />Bonos</button></div>
                    {(kind === 'stock' || kind === 'arg-stock') && <div className="seg" role="group" aria-label="Mercado de acciones"><button type="button" aria-label="Acciones de Estados Unidos" aria-pressed={kind === 'stock'} onClick={() => pickKind('stock')}><span aria-hidden="true" className="text-[18px] leading-none sm:hidden">🇺🇸</span><span className="hidden sm:inline">EE. UU.</span></button><button type="button" aria-label="Acciones de Argentina" aria-pressed={kind === 'arg-stock'} onClick={() => openLocalSearch('stocks')}><span aria-hidden="true" className="text-[18px] leading-none sm:hidden">🇦🇷</span><span className="hidden sm:inline">Argentina</span></button></div>}
                    {(kind === 'cedear' || kind === 'stock') && <div className="flex gap-2" role="group" aria-label={kind === 'stock' ? 'Tipo de acción' : 'Tipo de CEDEAR'}><button type="button" aria-pressed={!indexMode} onClick={() => pickKind(kind)} className="btn-ghost flex-1">{kind === 'stock' ? 'Acción' : 'CEDEAR'}</button><button type="button" aria-pressed={indexMode} onClick={() => { setIndexMode(true); setCurrency('USD'); setCoin('SPY'); setName('S&P 500 (SPY)'); setAssetQuote(null); setError(''); }} className={`flex items-center justify-center gap-2 rounded-[10px] border px-2 py-2.5 text-[12px] ${indexMode ? 'border-[var(--line2)] bg-[var(--raised)]' : 'border-[var(--line)] text-[var(--muted)]'}`}><span className="h-1.5 w-1.5 rounded-full" style={{ background: colorOf('index') }} />Índices</button></div>}
                    {indexMode && <div><label htmlFor="invest-index" className={label}>Índice de referencia</label><Select id="invest-index" label="Índice de referencia" value={coin} onChange={ticker => { setCoin(ticker); setName(`${indexName(ticker)} (${ticker})`.slice(0, 70)); setAssetQuote(null); setError(''); }} options={INDEXES.map(i => ({ value: i.symbol, label: `${i.name} · ${i.symbol}` }))} /><p className="mt-2 text-[11px] text-[var(--muted)]">{kind === 'stock' ? 'Se usa la cotización en dólares del ETF que sigue al índice.' : currency === 'USD' ? 'Se usa la cotización en pesos del CEDEAR del ETF y se convierte a USDC.' : 'Se usa la cotización en pesos del CEDEAR del ETF.'}</p></div>}
                    <div><label htmlFor="invest-name" className={label}>Nombre</label><input id="invest-name" required={kind === 'rate'} maxLength={70} className={field} value={name} onChange={e => setName(e.target.value)} placeholder="Ej: S&P 500, plazo fijo..." />{kind !== 'rate' && <p className="mt-1 text-[11px] text-[var(--muted)]">Si lo dejás vacío, se usará el nombre del activo.</p>}</div>
                    <div className="grid grid-cols-2 gap-3 [&>div]:min-w-0"><div><label htmlFor="invest-amount" className={label}>{editingId && items.find(item => item.id === editingId)?.costUnknown ? 'Costo total de compra' : kind === 'rate' ? 'Monto' : priceMode === 'purchase' ? 'Monto de compra' : 'Valor actual'} ({currency})</label><input id="invest-amount" required type="number" inputMode="decimal" min="0.000001" step="any" className={field} value={amount} onChange={e => setAmount(e.target.value)} placeholder="1000" /></div><div><label htmlFor="invest-currency" className={label}>Moneda</label>{kind === 'stock' || kind === 'cedear' || kind === 'arg-stock' || kind === 'bond' || kind === 'fund' ? <div className={field}>{kind === 'stock' || (indexMode && currency === 'USD') ? 'USD (USDC)' : currency === 'USD' ? 'USD (registro anterior)' : 'ARS'}</div> : <Select<Currency> id="invest-currency" label="Moneda" value={currency} onChange={setCurrency} options={[{ value: 'USD', label: 'USD' }, { value: 'ARS', label: 'ARS' }]} />}</div><div className="col-span-2 sm:col-span-1"><label htmlFor="invest-date" className={label}>Fecha de compra</label><input id="invest-date" required type="date" max={localISO()} className={field} value={date} onChange={e => { setDate(e.target.value); setError(''); }} /></div></div>
                    {kind !== 'rate' && !items.find(item => item.id === editingId)?.costUnknown && <fieldset><legend className={label}>¿Qué valor querés ingresar?</legend><div className="grid grid-cols-2 gap-2">{([{ value: 'current', label: 'Valor actual' }, { value: 'purchase', label: 'Valor de compra' }] as const).map(option => <button key={option.value} type="button" aria-pressed={priceMode === option.value} onClick={() => { setPriceMode(option.value); setError(''); }} className={`rounded-[10px] border px-3 py-2.5 text-[12px] ${priceMode === option.value ? 'border-[var(--line2)] bg-[var(--raised)]' : 'border-[var(--line)] text-[var(--muted)]'}`}>{option.label}</button>)}</div>{priceMode === 'purchase' && <div className="mt-3"><label htmlFor="purchase-price" className={label}>Precio de compra por unidad ({quoteCurrency})</label><input id="purchase-price" required type="number" inputMode="decimal" min="0.000000000001" step="any" className={field} value={purchasePrice} onChange={e => setPurchasePrice(e.target.value)} placeholder="Precio que pagaste por unidad" /><p className="mt-2 text-[11px] text-[var(--muted)]">Se calcula la cantidad de unidades con el monto y el precio de compra ingresados.</p></div>}</fieldset>}
                    {kind === 'rate' && <div><label htmlFor="deposit-maturity" className={label}>Vencimiento del plazo fijo (opcional)</label><input id="deposit-maturity" type="date" min={date} value={depositMaturity} onChange={event => { setDepositMaturity(event.target.value); if (event.target.value) setPeriod('year'); }} className={field} /><p className="mu mt-2 text-[11px] leading-5">Si ingresás un vencimiento, se calcula interés simple con la tasa nominal anual y se deja de acumular al vencer. No registra renovación automática.</p></div>}
                    {(kind === 'arg-stock' || kind === 'bond' || kind === 'fund') && <label className="flex items-start gap-2 text-[11px] text-[var(--muted)]"><input type="checkbox" checked={localConfirmed} onChange={event => setLocalConfirmed(event.target.checked)} /><span>Confirmo que la especie y la cotización corresponden a pesos{kind === 'bond' ? ' y que el precio publicado corresponde a 100 nominales' : ''}.</span></label>}
                    {kind !== 'rate' && currency !== quoteCurrency && <p className="text-[11px] text-[var(--muted)]">Para calcular las unidades y el valor en {currency} se usa el precio actual de USDC en pesos{officialRate ? ` (${money(officialRate, 'ARS')})` : ', no disponible en este momento'}. En compras anteriores no se usa la cotización histórica.</p>}
                    {kind === 'rate' ? <div className="grid grid-cols-2 gap-3"><div><label htmlFor="invest-rate" className={label}>Tasa (%)</label><input id="invest-rate" type="number" inputMode="decimal" step="any" className={field} value={rate} onChange={e => setRate(e.target.value)} placeholder="8" /></div><div><label htmlFor="invest-period" className={label}>Período</label><Select<Period> id="invest-period" label="Período" value={period} onChange={setPeriod} options={[{ value: 'year', label: 'Anual' }, { value: 'month', label: 'Mensual', disabled: !!depositMaturity }]} /></div></div> : <div>
                        <div className="mb-1.5 flex flex-wrap items-center justify-between gap-2"><label htmlFor="invest-coin" className="text-[12px] text-[var(--muted)]">{kind === 'fund' ? 'Fondo y clase' : kind === 'bond' ? 'Ticker del bono' : kind === 'arg-stock' || kind === 'stock' ? 'Ticker de la acción' : kind === 'cedear' ? 'Ticker del CEDEAR' : 'ID de CoinGecko'}</label>{<button type="button" onClick={() => kind === 'arg-stock' || kind === 'bond' || kind === 'fund' ? openLocalSearch(kind === 'arg-stock' ? 'stocks' : kind === 'bond' ? 'bonds' : 'funds') : (setInitialLocalSearch(undefined), setAssetSearch(indexMode ? 'index' : kind === 'cedear' ? 'cedear' : kind === 'stock' ? 'stock' : 'crypto'))} className="inline-flex items-center gap-1.5 text-[11px] text-[var(--ink)] underline underline-offset-4"><HugeiconsIcon icon={Search01Icon} size={13} />Buscar {kind === 'crypto' ? 'criptomoneda' : indexMode ? 'índice' : kind === 'stock' || kind === 'arg-stock' ? 'acciones' : kind === 'fund' ? 'FCI' : kind === 'bond' ? 'bonos' : 'CEDEAR'}</button>}</div>
                        <input id="invest-coin" className={field} required readOnly={indexMode || kind === 'arg-stock' || kind === 'bond' || kind === 'fund'} value={coin} autoCapitalize="none" autoCorrect="off" spellCheck={false} aria-describedby="coin-help" onChange={e => { const nextId = kind !== 'crypto' ? e.target.value.trim().toUpperCase() : e.target.value.trim().toLowerCase(); if (nextId !== assetId) setAssetQuote(null); setCoin(e.target.value); setError(''); }} placeholder={kind !== 'crypto' ? 'AAPL, SPY, MELI' : 'bitcoin, ethereum, solana'} />
                        <p id="coin-help" className="mt-2 font-mono text-[10px] text-[var(--muted)]">{kind === 'fund' ? 'Clase y precio publicados por ArgentinaDatos.' : kind === 'arg-stock' || kind === 'bond' ? 'Cotización orientativa de Data912 en pesos.' : kind === 'crypto' ? 'Se consulta el precio actual en CoinGecko.' : kind === 'stock' ? 'Ingresá el ticker de la acción estadounidense. Cotización en USD.' : 'Ingresá el ticker en pesos. Se consulta su última cotización.'}</p>
                        <div className="mt-3 rounded-xl border border-[var(--line2)] bg-[var(--raised)] p-3.5" aria-live="polite" aria-atomic="true">
                            {!assetId ? <p className="text-[12px] text-[var(--muted)]">Ingresá {kind !== 'crypto' ? 'un ticker' : 'un ID'} para consultar su precio.</p> : activeQuote?.status === 'error' ? <>
                                <p role="alert" className="text-[12px] text-[var(--neg)]">{activeQuote.message}</p>
                                <button type="button" onClick={() => { setAssetQuote(null); setQuoteRequest(value => value + 1); setError(''); }} className="mt-3 inline-flex items-center gap-1.5 text-[12px] underline underline-offset-4"><HugeiconsIcon icon={Refresh04Icon} size={13} />Reintentar consulta</button>
                            </> : activeQuote?.status === 'ready' ? <>
                                <div className="flex items-start justify-between gap-3"><div className="min-w-0"><p className="text-[11px] text-[var(--muted)]">{kind === 'cedear' ? 'Última cotización por unidad' : 'Precio actual por unidad'}</p><p className="mt-1 break-words font-mono text-[22px] leading-tight tracking-tight">{new Intl.NumberFormat('es-AR', { style: 'currency', currency: quoteCurrency, currencyDisplay: 'code', ...(activeQuote.price < 1 ? { maximumSignificantDigits: 6 } : { minimumFractionDigits: 2, maximumFractionDigits: 2 }) }).format(activeQuote.price)}</p></div><QuoteSource source={kind === 'fund' ? 'fund' : kind === 'arg-stock' || kind === 'bond' ? 'local' : kind === 'stock' ? 'stock' : kind === 'cedear' ? 'cedear' : 'crypto'} asset={assetId} className="shrink-0 rounded-md bg-[var(--sig)]/10 px-2 py-1" /></div>
                                {kind === 'crypto' ? <a href={`https://www.coingecko.com/en/coins/${encodeURIComponent(assetId)}`} target="_blank" rel="noopener noreferrer" className="mt-2 inline-block break-all font-mono text-[11px] text-[var(--muted)] underline underline-offset-4">{assetId}</a> : <p className="mt-2 font-mono text-[11px] text-[var(--muted)]">{assetId.split('~')[0]} · {kind === 'stock' ? 'Acción en USD' : kind === 'arg-stock' ? 'Acción en pesos' : kind === 'bond' ? 'Precio por nominal en pesos' : kind === 'fund' ? 'Valor de cuotaparte' : 'CEDEAR en pesos'}</p>}
                                {previewUnits != null && Number.isFinite(previewUnits) && <div className="mt-3 flex flex-wrap items-center justify-between gap-2 border-t border-[var(--line)] pt-3 text-[12px]"><span className="text-[var(--muted)]">Unidades estimadas</span><span className="break-all font-mono">{new Intl.NumberFormat('es-AR', { maximumSignificantDigits: 10 }).format(previewUnits)}</span></div>}
                                <p className="mt-2 text-[10px] text-[var(--muted)]">{priceMode === 'purchase' ? 'La cotización actual se usa para valorar tu inversión.' : 'Se usa el precio actual para estimar las unidades; el monto ingresado se toma como valor actual.'}</p>
                            </> : <p role="status" className="flex items-center gap-2 text-[12px] text-[var(--muted)]"><HugeiconsIcon icon={LoaderIcon} size={15} className="animate-spin" />Consultando {quoteSource}...</p>}
                        </div>
                    </div>}
                    {error && <p role="alert" className="rounded-lg bg-[var(--neg)]/10 p-3 text-[12px] text-[var(--neg)]">{error}</p>}
                    <div className="flex gap-2 border-t border-[var(--line)] pt-5"><button type="button" onClick={closeModal} className="flex-1 rounded-[10px] border border-[var(--line2)] bg-[var(--raised)] py-3 text-[13px]">Cancelar</button><button type="submit" disabled={kind !== 'rate' && priceMode === 'current' && quotePrice == null} className="flex-[1.3] rounded-[10px] bg-[var(--ink)] py-3 text-[13px] font-medium text-[var(--bg)] disabled:opacity-50">{editingId ? 'Guardar cambios' : 'Guardar inversión'}</button></div>
                </form>
            </div>
        </div>}
        {emailSettings && <EmailSettingsDialog returnToSpace={spaceSubscreen === 'mail'} onClose={() => { setEmailSettings(false); setSpaceSubscreen(null); setEmailSettingsRevision(value => value + 1); }} />}
        {benchmarkSearchOpen && <AssetSearchDialog benchmarkMode onCompareLocal={selectTemporaryBenchmark} onClose={() => setBenchmarkSearchOpen(false)} footer="El activo se usa solo para esta comparación y no se guarda en tu cartera." onSelect={selectTemporaryBenchmark} />}
        {assetSearch && <AssetSearchDialog initial={assetSearch} initialLocal={initialLocalSearch} onChooseLocal={selectLocalAsset} onClose={() => { setAssetSearch(null); setInitialLocalSearch(undefined); }} onSelect={selectAsset} onAddLocal={investment => { setItems(prev => [...prev, investment]); setAssetSearch(null); setInitialLocalSearch(undefined); setModal(false); setNotice('Inversión agregada. Se está guardando en tu cuenta.'); }} />}
        {confirmDelete && <div className="fixed inset-0 z-[60] grid place-items-center bg-black/65 p-4 backdrop-blur-sm"><div role="alertdialog" aria-modal="true" aria-labelledby="delete-title" className={`${panel} w-full max-w-[390px] p-6 shadow-2xl`}><h2 id="delete-title" className="text-[20px] font-medium">Eliminar inversión</h2><p className="mt-2 text-[13px] text-[var(--muted)]">Esta acción no se puede deshacer. ¿Querés eliminar esta posición de tu cartera?</p><div className="mt-6 flex justify-end gap-2"><button onClick={() => setConfirmDelete(null)} className="rounded-lg border border-[var(--line2)] px-4 py-2.5 text-[13px]">Cancelar</button><button onClick={() => { setItems(prev => prev.filter(i => i.id !== confirmDelete)); setConfirmDelete(null) }} className="rounded-lg bg-[var(--neg)] px-4 py-2.5 text-[13px] font-medium text-white">Eliminar</button></div></div></div>}
        {importPreview && <div className="fixed inset-0 z-[60] grid place-items-center bg-black/65 p-4 backdrop-blur-sm"><div role="alertdialog" aria-modal="true" aria-labelledby="import-title" className={`${panel} w-full max-w-[430px] p-6 shadow-2xl`}><h2 id="import-title" className="text-[20px] font-medium">Importar inversiones</h2><p className="mt-2 text-[13px] text-[var(--muted)]">Se encontraron <strong className="font-medium text-[var(--ink)]">{importPreview.items.length}</strong> inversiones válidas{importPreview.skipped > 0 ? ` (${importPreview.skipped} inválidas se van a omitir)` : ''}. Tenés {items.length} cargadas ahora.</p><ul className="mt-4 space-y-1.5 text-[12px] text-[var(--muted)]"><li><strong className="font-medium text-[var(--ink)]">Combinar:</strong> suma las nuevas y omite las que ya existen.</li><li><strong className="font-medium text-[var(--ink)]">Reemplazar:</strong> borra tu cartera actual y deja solo el archivo.</li></ul><div className="mt-6 flex flex-wrap justify-end gap-2"><button onClick={() => setImportPreview(null)} className="rounded-lg border border-[var(--line2)] px-4 py-2.5 text-[13px]">Cancelar</button><button onClick={() => applyImport('replace')} className="rounded-lg border border-[var(--neg)]/40 px-4 py-2.5 text-[13px] text-[var(--neg)]">Reemplazar</button><button onClick={() => applyImport('merge')} className="rounded-lg bg-[var(--ink)] px-4 py-2.5 text-[13px] font-medium text-[var(--bg)]">Combinar</button></div></div></div>}
    </div>;
}

